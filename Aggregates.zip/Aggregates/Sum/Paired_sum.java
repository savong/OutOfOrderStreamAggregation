/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bidirectional_incremental_computation;

/**
 *
 * @author savong
 */

import java.io.Serializable;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Stack;
import org.apache.flink.api.common.functions.FlatMapFunction;
import org.apache.flink.api.common.functions.FoldFunction;
import org.apache.flink.api.java.tuple.Tuple11;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.windowing.evictors.CountEvictor;
import org.apache.flink.streaming.api.windowing.triggers.CountTrigger;
import org.apache.flink.streaming.api.windowing.triggers.PurgingTrigger;
import org.apache.flink.util.Collector;
import java.lang.management.*;
/**
 *
 * @author bousavong
 */
public class Paired_sum {
    public static void Paired{
        // TODO code application logic here
        final StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        //env.setStreamTimeCharacteristic(TimeCharacteristic.ProcessingTime);
        //env.setParallelism(1);
        DataStream<Tuple2<Integer,Integer>> datastream = env.readTextFile("/DEBS2012_Dataset/DEBS2012_129millions.txt")//DEB12/DEBS2012-ChallengeData.txt") //5000000.txt //50000.txt
        .flatMap(new LineSplitter2());
        
        long startCpuTimeNano = getCpuTime( );
        long startSystemTimeNano = getSystemTime( );
        long startUserTimeNano   = getUserTime( );
        long tStart= System.currentTimeMillis();//=0;// = System.currentTimeMillis();
        long tEnd=0;
        double elapsedSeconds=0.0;
        

        int range = 10000000;
            int slide = 1;
            int f2 = range%slide;
            int f1 = slide - f2;
            int num_slide;
            if(f2==0)
                num_slide = 2*(range/slide);
            else
                num_slide = 2* (int) Math.floor(range/(float)slide)+1;
            //int num_slide = 2* (int) Math.floor(range/(float)slide);
                        
            datastream
            .keyBy(0)
            .countWindow(range,slide).trigger(PurgingTrigger.of(CountTrigger.of(slide)))//.evictor(CountEvictor.of(slide))
            .fold(new Integer (0), new FoldFunction<Tuple2<Integer, Integer>, Integer>() {
               HashMap<Integer, Tuple2<Integer, Integer>> agg = new HashMap<Integer, Tuple2<Integer, Integer>>();
               int f1_value=0;
               int f2_value=0;
               int count=0;
               int round_tmp=0;
               int round=0;
               @Override
               public Integer fold(Integer acc, Tuple2<Integer, Integer> value) throws Exception{
                count++;
                round_tmp++;

                //acc+=value.f1;
                if(count<=f1)
                {
                    f1_value+=value.f1;
                }
                else if (count <= f2+f1)
                {
                    f2_value+=value.f1;
                }

                //if(round_tmp%slide==0)
                if(round_tmp>=slide)
                {
                    round_tmp=0;
                    round++;
                    agg.put(round, new Tuple2<>(value.f0,f1_value));
                    if(round==num_slide)
                        round=0;
                    round++;
                    agg.put(round, new Tuple2<>(value.f0,f2_value));
                    if(round==num_slide)
                        round=0;
                    count=0;
                    f1_value=0;
                    f2_value=0;
                Integer result=0;

                for(Map.Entry<Integer, Tuple2<Integer, Integer>> entry : agg.entrySet())
                {
                    result += entry.getValue().f1;
                }
                acc = result;
                }
                   return acc;
               }
            });//.print();//.writeAsText("/Users/bousavong/Desktop/test/text/DEB12/pair.txt");//.print();

        env.execute("Word Count Example");
        tEnd = System.currentTimeMillis();
        elapsedSeconds = (tEnd - tStart) / 1000.0;
        double taskCpuTimeNano    = (getCpuTime( ) - startCpuTimeNano) / 1000000000.0;
        double taskUserTimeNano    = (getUserTime( ) - startUserTimeNano) / 1000000000.0;
        double taskSystemTimeNano  = (getSystemTime( ) - startSystemTimeNano) / 1000000000.0;
        System.out.println("taskCpuTimeNano:"+taskCpuTimeNano);
        System.out.println("taskUserTimeNano:"+taskUserTimeNano);
        System.out.println("taskSystemTimeNano:"+taskSystemTimeNano);
        System.out.println("Time:"+elapsedSeconds);
        System.out.println("Finish");
    }
    public static class LineSplitter implements FlatMapFunction<String, Tuple11<Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer>> {
        @Override
        public void flatMap(String line, Collector<Tuple11<Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer>> out) {
            String[] cells = line.split("\\s+");
            out.collect(new Tuple11<>(1, Integer.parseInt(cells[1]), Integer.parseInt(cells[2]), Integer.parseInt(cells[3]), Integer.parseInt(cells[4]), Integer.parseInt(cells[5]), Integer.parseInt(cells[6]), Integer.parseInt(cells[7]), Integer.parseInt(cells[8]), Integer.parseInt(cells[9]), Integer.parseInt(cells[10])));
        }
    }

    public static class LineSplitter2 implements FlatMapFunction<String, Tuple2<Integer, Integer>> {
        @Override
        public void flatMap(String line, Collector<Tuple2<Integer, Integer>> out) {
            String[] cells = line.split("\\s+");
            //out.collect(new Tuple2<>(Integer.parseInt(cells[1]), Integer.parseInt(cells[2])));
            out.collect(new Tuple2<>(1, Integer.parseInt(cells[2])));
        }
    }
    
            // Get CPU time in nanoseconds. 
public static long getCpuTime( ) {
    ThreadMXBean bean = ManagementFactory.getThreadMXBean( );
    return bean.isCurrentThreadCpuTimeSupported( ) ?
        bean.getCurrentThreadCpuTime( ) : 0L;
}
 
// Get user time in nanoseconds. 
public static long getUserTime( ) {
    ThreadMXBean bean = ManagementFactory.getThreadMXBean( );
    return bean.isCurrentThreadCpuTimeSupported( ) ?
        bean.getCurrentThreadUserTime( ) : 0L;
}

// Get system time in nanoseconds. 
public static long getSystemTime( ) {
    ThreadMXBean bean = ManagementFactory.getThreadMXBean( );
    return bean.isCurrentThreadCpuTimeSupported( ) ?
        (bean.getCurrentThreadCpuTime( ) - bean.getCurrentThreadUserTime( )) : 0L;
}
}
