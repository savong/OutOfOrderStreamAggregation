/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bidirectional_incremental_computation;

/**
 *
 * @author savong
 */

import java.io.Serializable;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Stack;
import org.apache.flink.api.common.functions.FlatMapFunction;
import org.apache.flink.api.common.functions.FoldFunction;
import org.apache.flink.api.java.tuple.Tuple11;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.windowing.evictors.CountEvictor;
import org.apache.flink.streaming.api.windowing.triggers.CountTrigger;
import org.apache.flink.streaming.api.windowing.triggers.PurgingTrigger;
import org.apache.flink.util.Collector;
import java.lang.management.*;
/**
 *
 * @author bousavong
 */
public class FlatFIT_sum {
    public static void FlatFIT{

        // TODO code application logic here
        final StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        //env.setStreamTimeCharacteristic(TimeCharacteristic.ProcessingTime);
        //env.setParallelism(1);
        DataStream<Tuple2<Integer,Integer>> datastream = env.readTextFile("/DEBS2012_Dataset/DEBS2012_129millions.txt")//DEB12/DEBS2012-ChallengeData.txt") //5000000.txt //50000.txt
        .flatMap(new LineSplitter2());
        
                long startCpuTimeNano = getCpuTime( );
        long startSystemTimeNano = getSystemTime( );
        long startUserTimeNano   = getUserTime( );
        long tStart= System.currentTimeMillis();//=0;// = System.currentTimeMillis();
        long tEnd=0;
        double elapsedSeconds=0.0;

        
        int range = 1000;
        int slide = 1;
        int f2 = range%slide;
        int f1 = slide - f2;
        if(f2==0)
        {
            int num_slide = range/slide;
            double parent_forward_aggregate=0.0;
            double results = 0.0;
            ArrayList<Double> Partials = new ArrayList<>();
            ArrayList<Integer> Pointers = new ArrayList<>();
            Stack Positions = new Stack();
            for(int i=0;i<num_slide;i++)
            {
                Partials.add(i, 0.0);
                Pointers.add(i, i+1);
            }
            Pointers.set(num_slide-1, 0);
            //int currInd=0;
            //int prevInd=range-1;
            datastream
            .keyBy(0)
            .countWindow(range,slide).trigger(PurgingTrigger.of(CountTrigger.of(slide)))//.evictor(CountEvictor.of(slide))
            .fold(new Integer (0), new FoldFunction<Tuple2<Integer, Integer>, Integer>() {
               double f1_value=0;
               double f2_value=0;
               int count=0;
               int round_tmp=0;
               int round=0;
               int currInd=0;
               int prevInd=num_slide-1;

               @Override
               public Integer fold(Integer acc, Tuple2<Integer, Integer> value) throws Exception{
                    count++;
                    round_tmp++;

                    if(count<=f1)
                    {
                        f1_value+=value.f1;
                    }

                    //if(round_tmp%slide==0)
                    if(round_tmp>=slide)
                    {
                        round_tmp=0;
                        round++;
                        Partials.set(prevInd, f1_value);
                        Pointers.set(prevInd, currInd);
                        int startInd=currInd-num_slide;
                        if(startInd<0)
                        {
                            startInd+=num_slide;
                        }
                        do
                        {
                            Positions.push(startInd);
                            startInd=Pointers.get(startInd);
                        }while(startInd != currInd);
                        int p_k=0;
                        if(Positions.size()>1)
                            p_k = (int)Positions.pop();
                        double answer=Partials.get(p_k);
                        int tempInd=0;
                        while(Positions.size()>1)
                        {
                            tempInd = (int)Positions.pop();
                            answer+=Partials.get(tempInd);
                            Partials.set(tempInd, answer);
                            Pointers.set(tempInd, currInd);
                        }
                        if(Positions.size()>1)
                        tempInd = (int)Positions.pop();
                        answer+=Partials.get(tempInd);
                        prevInd = currInd;
                        currInd++;
                        if(currInd == num_slide)
                            currInd=0;
                        count=0;
                        f1_value=0;
                        acc = (int)answer;
                    }
                    return acc;
               }
            });//.print();//.writeAsText("/Users/bousavong/Desktop/test/text/DEB12/flatfit.txt");//.print();
        }
        else
        {

        }

        env.execute("Word Count Example");
        tEnd = System.currentTimeMillis();
        elapsedSeconds = (tEnd - tStart) / 1000.0;
        double taskCpuTimeNano    = (getCpuTime( ) - startCpuTimeNano) / 1000000000.0;
        double taskUserTimeNano    = (getUserTime( ) - startUserTimeNano) / 1000000000.0;
        double taskSystemTimeNano  = (getSystemTime( ) - startSystemTimeNano) / 1000000000.0;
        System.out.println("taskCpuTimeNano:"+taskCpuTimeNano);
        System.out.println("taskUserTimeNano:"+taskUserTimeNano);
        System.out.println("taskSystemTimeNano:"+taskSystemTimeNano);
        System.out.println("Time:"+elapsedSeconds);
        System.out.println("Finish");
    }
    public static class LineSplitter implements FlatMapFunction<String, Tuple11<Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer>> {
        @Override
        public void flatMap(String line, Collector<Tuple11<Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer>> out) {
            String[] cells = line.split("\\s+");
            out.collect(new Tuple11<>(1, Integer.parseInt(cells[1]), Integer.parseInt(cells[2]), Integer.parseInt(cells[3]), Integer.parseInt(cells[4]), Integer.parseInt(cells[5]), Integer.parseInt(cells[6]), Integer.parseInt(cells[7]), Integer.parseInt(cells[8]), Integer.parseInt(cells[9]), Integer.parseInt(cells[10])));
        }
    }

    public static class LineSplitter2 implements FlatMapFunction<String, Tuple2<Integer, Integer>> {
        @Override
        public void flatMap(String line, Collector<Tuple2<Integer, Integer>> out) {
            String[] cells = line.split("\\s+");
            //out.collect(new Tuple2<>(Integer.parseInt(cells[1]), Integer.parseInt(cells[2])));
            out.collect(new Tuple2<>(1, Integer.parseInt(cells[2])));
        }
    }
           // Get CPU time in nanoseconds. 
public static long getCpuTime( ) {
    ThreadMXBean bean = ManagementFactory.getThreadMXBean( );
    return bean.isCurrentThreadCpuTimeSupported( ) ?
        bean.getCurrentThreadCpuTime( ) : 0L;
}
 
// Get user time in nanoseconds. 
public static long getUserTime( ) {
    ThreadMXBean bean = ManagementFactory.getThreadMXBean( );
    return bean.isCurrentThreadCpuTimeSupported( ) ?
        bean.getCurrentThreadUserTime( ) : 0L;
}

// Get system time in nanoseconds. 
public static long getSystemTime( ) {
    ThreadMXBean bean = ManagementFactory.getThreadMXBean( );
    return bean.isCurrentThreadCpuTimeSupported( ) ?
        (bean.getCurrentThreadCpuTime( ) - bean.getCurrentThreadUserTime( )) : 0L;
}
}
