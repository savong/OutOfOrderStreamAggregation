/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bidirectional_incremental_computation;

/**
 *
 * @author savong
 */
import java.io.Serializable;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Stack;
import org.apache.flink.api.common.functions.FlatMapFunction;
import org.apache.flink.api.common.functions.FoldFunction;
import org.apache.flink.api.java.tuple.Tuple11;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.windowing.evictors.CountEvictor;
import org.apache.flink.streaming.api.windowing.triggers.CountTrigger;
import org.apache.flink.streaming.api.windowing.triggers.PurgingTrigger;
import org.apache.flink.util.Collector;
import java.lang.management.*;
/**
 *
 * @author bousavong
 */
public class DABA_avg {
public static void DABA{
// TODO code application logic here
final StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
//env.setStreamTimeCharacteristic(TimeCharacteristic.ProcessingTime);
//env.setParallelism(1);




DataStream<Tuple2<Integer,Integer>> datastream = env.readTextFile("/DEBS2012_Dataset/DEBS2012_129millions.txt")//DEB12/DEBS2012-ChallengeData.txt") //5000000.txt //50000.txt
.flatMap(new LineSplitter2());



        long startCpuTimeNano = getCpuTime( );
        long startSystemTimeNano = getSystemTime( );
        long startUserTimeNano   = getUserTime( );
        long tStart= System.currentTimeMillis();//=0;// = System.currentTimeMillis();
        long tEnd=0;
        Double elapsedSeconds=0.0;


int range = 100000;
int slide = 1;
int f2 = range%slide;
int f1 = slide - f2;
if(f2==0)
{
    int num_slide = range/slide;
    //Stack<Node> F = new Stack();
    //Stack<Node> B = new Stack();
    DoublyLinkedList vals = new DoublyLinkedList();
    DoublyLinkedList aggs = new DoublyLinkedList();


    datastream
    .keyBy(0)
    .countWindow(range,slide).trigger(PurgingTrigger.of(CountTrigger.of(slide)))//.evictor(CountEvictor.of(slide))
    .fold(new Double (0.0), new FoldFunction<Tuple2<Integer, Integer>, Double>() {
    int f1_value=0;
    int count=0;
    int round_tmp=0;
    int round=0;
    int window=0;
    int F=1;
    int L=1;
    int R=1;
    int A=1;
    int B=1;
    int E=1;
    boolean n_round = false;
    //DoublyLinkedList vals = new DoublyLinkedList(new double[num_slide]);
    //DoublyLinkedList aggs = new DoublyLinkedList(new double[num_slide]);


    double AggF=0; double AggL=0; double AggR=0; double AggA=0; double AggB=0; double AggE=0;
    @Override
    public Double fold(Double acc, Tuple2<Integer, Integer> value) throws Exception{
        count++;
        round_tmp++;
        window++;
        if(count<=f1)
        {
            f1_value+=value.f1;
        }
        //if(round_tmp%slide==0)
        if(round_tmp>=slide)
        {
            round++;
            if(F==B)
                AggF=0;
            else
                AggF=aggs.get(F).head;

            if(B==E)
                AggB=0;
            else
                AggB=aggs.get(E-1).head;

            if(window > range)
                {
                //Evict
                vals.remove(1);
                aggs.remove(1);
                L=L-1; R=R-1; A=A-1; B=B-1; E=E-1;
                //Fixup
                if(F==B)
                {
                    B=E; A=E; R=E; L=E;
                }
                else
                {
                    if(L==B)
                    {
                        L=F; A=E; B=E;
                    }
                    if(L==R)
                    {
                        A=A+1; R=R+1; L=L+1;
                    }
                    else
                    {
                        if(L==R)
                            AggL=0;
                        else
                            AggL=aggs.get(L).head;

                        if(R==A)
                            AggR=0;
                        else
                            AggR=aggs.get(A-1).head;

                        if(A==B)
                            AggA=0;
                        else
                            AggA=aggs.get(A).head;

                        aggs.get(L).head = AggL+AggR+AggA;
                        //System.out.println("aggs: "+aggs.toString());
                        L=L+1;
                        aggs.get(A-1).head= vals.get(A-1).head+AggA;
                        //System.out.println("aggs: "+aggs.toString());
                        A=A-1;

                    }
                }
            }

            if(F==B)
                AggF=0;
            else
                AggF=aggs.get(F).head;

            if(B==E)
                AggB=0;
            else
                AggB=aggs.get(E-1).head;
            //Insert
            vals.insertBack(f1_value);
            aggs.insertBack(f1_value+AggB);
            //System.out.println("vals: "+vals.toString());
            //System.out.println("aggs: "+aggs.toString());
            E++;
            //Fixup
            if(F==B)
            {
                B=E; A=E; R=E; L=E;
            }
            else
            {
                if(L==B)
                {
                    L=F; A=E; B=E;
                }
                if(L==R)
                {
                    A=A+1; R=R+1; L=L+1;
                }
                else
                {
                    if(L==R)
                        AggL=0;
                    else
                        AggL=aggs.get(L).head;

                    if(R==A)
                        AggR=0;
                    else
                        AggR=aggs.get(A-1).head;

                    if(A==B)
                        AggA=0;
                    else
                        AggA=aggs.get(A).head;

                    aggs.get(L).head = AggL+AggR+AggA;
                    //System.out.println("aggs: "+aggs.toString());
                    L=L+1;
                    aggs.get(A-1).head= vals.get(A-1).head+AggA;
                    //System.out.println("aggs: "+aggs.toString());
                    A=A-1;
                }
            }


            if(F==B)
                AggF=0;
            else
                AggF=aggs.get(F).head;

            if(B==E)
                AggB=0;
            else
                AggB=aggs.get(E-1).head;

            //result
            double results = AggF+AggB;


            count=0;
            f1_value=0;
            round_tmp=0;
            //acc = results;
            if(round==num_slide)
            {
                n_round = true;
                round=0;
            }
            if(n_round)
                acc = (double)results/range;
            else
                acc = (double)results/(round*slide);
        }
        return acc;
    }
    });
}
else
{
    //Stack<Node> F = new Stack();
    //Stack<Node> B = new Stack();
    int num_slide = range/slide+1;


    datastream
    .keyBy(0)
    .countWindow(range,slide).trigger(PurgingTrigger.of(CountTrigger.of(slide)))//.evictor(CountEvictor.of(slide))
    .fold(new Integer (0), new FoldFunction<Tuple2<Integer, Integer>, Integer>() {
    int f1_value=0;
    int f2_value=0;
    int count=0;
    int round_tmp=0;
    int round=0;
    int window = 0;
    @Override
    public Integer fold(Integer acc, Tuple2<Integer, Integer> value) throws Exception{
    count++;
    round_tmp++;
    window++;
    if(count<=f1)
    {
        f1_value+=value.f1;
    }
    else if (count <= f2+f1)
    {
        f2_value+=value.f1;
    }

    //double forward_aggregate = tree_aggregation[round]+f1_value;
    if(round_tmp>=slide)
    {


        round++;
        if(round==num_slide)
            round=0;

        //result
        double results=0.0;


        count=0;
        f1_value=0;
        f2_value=0;
        round_tmp=0;
        acc = (int)results;
    }
    return acc;
    }
    });
}
    env.execute("Word Count Example");
    tEnd = System.currentTimeMillis();
    elapsedSeconds = (tEnd - tStart) / 1000.0;
    double taskCpuTimeNano    = (getCpuTime( ) - startCpuTimeNano) / 1000000000.0;
    double taskUserTimeNano    = (getUserTime( ) - startUserTimeNano) / 1000000000.0;
    double taskSystemTimeNano  = (getSystemTime( ) - startSystemTimeNano) / 1000000000.0;
    System.out.println("taskCpuTimeNano:"+taskCpuTimeNano);
    System.out.println("taskUserTimeNano:"+taskUserTimeNano);
    System.out.println("taskSystemTimeNano:"+taskSystemTimeNano);
    System.out.println("Time:"+elapsedSeconds);
    System.out.println("Finish");

}
public static class LineSplitter implements FlatMapFunction<String, Tuple11<Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer>> {
    @Override
    public void flatMap(String line, Collector<Tuple11<Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer>> out) {
        String[] cells = line.split("\\s+");
        out.collect(new Tuple11<>(1, Integer.parseInt(cells[1]), Integer.parseInt(cells[2]), Integer.parseInt(cells[3]), Integer.parseInt(cells[4]), Integer.parseInt(cells[5]), Integer.parseInt(cells[6]), Integer.parseInt(cells[7]), Integer.parseInt(cells[8]), Integer.parseInt(cells[9]), Integer.parseInt(cells[10])));
    }
}

public static class LineSplitter2 implements FlatMapFunction<String, Tuple2<Integer, Integer>> {
    @Override
    public void flatMap(String line, Collector<Tuple2<Integer, Integer>> out) {
        String[] cells = line.split("\\s+");
        //out.collect(new Tuple2<>(Integer.parseInt(cells[1]), Integer.parseInt(cells[2])));
        out.collect(new Tuple2<>(1, Integer.parseInt(cells[2])));
    }
}

           // Get CPU time in nanoseconds. 
public static long getCpuTime( ) {
    ThreadMXBean bean = ManagementFactory.getThreadMXBean( );
    return bean.isCurrentThreadCpuTimeSupported( ) ?
        bean.getCurrentThreadCpuTime( ) : 0L;
}
 
// Get user time in nanoseconds. 
public static long getUserTime( ) {
    ThreadMXBean bean = ManagementFactory.getThreadMXBean( );
    return bean.isCurrentThreadCpuTimeSupported( ) ?
        bean.getCurrentThreadUserTime( ) : 0L;
}

// Get system time in nanoseconds. 
public static long getSystemTime( ) {
    ThreadMXBean bean = ManagementFactory.getThreadMXBean( );
    return bean.isCurrentThreadCpuTimeSupported( ) ?
        (bean.getCurrentThreadCpuTime( ) - bean.getCurrentThreadUserTime( )) : 0L;
}


public static class DoublyLinkedList implements Serializable{// implements List {
public DNode sentinel;

public DoublyLinkedList(double[] array) {
    sentinel = new DNode(0);
    fromArray(array);
}

public DoublyLinkedList() {
    sentinel = new DNode(0);
}

//
// Converts an array of ints into a DoublyLinkedList
// of ints.
// @param array : array of ints
//
public void fromArray(double[] array) {
    DNode pointer = sentinel;
    for (int i=0;i<array.length;i++) {
        sentinel.head += 1;
        pointer.next = new DNode(pointer, array[i], null);
        pointer = pointer.next;
    }
}


// Get element at index i, or get the last element if
// the index is beyond the length of the list.
// @param i
// @return

public DNode get(int i) {
    DNode pointer = sentinel;
    while (i > 0 && pointer.next != null) {
        pointer = pointer.next;
        i -= 1;
    }
    return pointer;
}


// Inserts a given value into the doubly-linked list:
// - inserts at the end if the index exceeds array length
// - inserts at 0th index if index if negative
// @param i: int
// @param value: int

public void insert(int i, double value) {
    DNode pointer = get(i);
    DNode insert = new DNode(pointer, value, pointer.next);
    if (pointer.next != null)
        pointer.next.prev = insert;
    pointer.next = insert;
    sentinel.head += 1;
}


// Removes, from the doubly-linked list, the element at
// the specified index, or terminate if the index given
// is invalid.
// @param i: int

public void remove(int i) {
    if (i < 0 || i >= sentinel.head) return;
        DNode pointer = get(i-1);
    if (pointer.next.next != null)
        pointer.next.next.prev = pointer;
    pointer.next = pointer.next.next;
    sentinel.head-= 1;
}


// Convert doubly-linked list into a string representation
// for testing use.
// @return String

public String toString() {
    DNode pointer = sentinel.next;
    StringBuilder str = new StringBuilder("[");
    while (pointer != null) {
        str.append(pointer.head+" ");
        pointer = pointer.next;
    }
    return str.append("]").toString();
}

// Making insertFront easier with general insert function
public void insertFront(double value) {
    insert(0, value);
}

// Making insertBack easier with insert and sentinel (size)
public void insertBack(double value) {
    insert((int)sentinel.head, value);
}

class DNode implements Serializable{
    public double head;
    public DNode prev;
    public DNode next;

    public DNode(double _head) {
        head = _head;
    }

    public DNode(DNode _prev, double _head, DNode _next) {
        prev = _prev;
        head = _head;
        next = _next;
    }
}
}
}
