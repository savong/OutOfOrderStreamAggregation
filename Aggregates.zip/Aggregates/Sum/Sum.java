/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bidirectional_incremental_computation;

/**
 *
 * @author savong
 */

import java.io.Serializable;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Stack;
import org.apache.flink.api.common.functions.FlatMapFunction;
import org.apache.flink.api.common.functions.FoldFunction;
import org.apache.flink.api.java.tuple.Tuple11;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.windowing.evictors.CountEvictor;
import org.apache.flink.streaming.api.windowing.triggers.CountTrigger;
import org.apache.flink.streaming.api.windowing.triggers.PurgingTrigger;
import org.apache.flink.util.Collector;
import java.lang.management.*;
/**
 *
 * @author bousavong
 */
/*
//Panes Approach ========================Begin 201796===========================
//Panes Approach ========================Begin 201796===========================
//Panes Approach ========================Begin 201796===========================
//Panes Approach ========================Begin 201796===========================
//Panes Approach ========================Begin 201796===========================
//Panes Approach ========================Begin 201796===========================

public class Sum {
    public static void main(String[] args) throws Exception{
        // TODO code application logic here
        final StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        //env.setStreamTimeCharacteristic(TimeCharacteristic.ProcessingTime);
        //env.setParallelism(1);
        DataStream<Tuple2<Integer,Integer>> datastream = env.readTextFile("/home/savong/デスクトップ/DEBS2012_Dataset/DEBS2012_129millions.txt")//DEB12/DEBS2012-ChallengeData.txt") //5000000.txt //50000.txt
        .flatMap(new LineSplitter2());
        
        long startCpuTimeNano = getCpuTime( );
        long startSystemTimeNano = getSystemTime( );
        long startUserTimeNano   = getUserTime( );
        long tStart= System.currentTimeMillis();//=0;// = System.currentTimeMillis();
        long tEnd=0;
        double elapsedSeconds=0.0;
        

        int range = 10000000;
        int slide = 1;
        int pane = gcdThing(range, slide);
        int num_slide = range/pane;
        datastream
        .keyBy(0)
        .countWindow(range,slide).trigger(PurgingTrigger.of(CountTrigger.of(slide)))//.evictor(CountEvictor.of(slide))
        .fold(new Integer (0), new FoldFunction<Tuple2<Integer, Integer>, Integer>() {
           HashMap<Integer, Tuple2<Integer, Integer>> agg = new HashMap<Integer, Tuple2<Integer, Integer>>();
           int f1_value=0;
           int count=0;
           int round_tmp=0;
           int round=0;
           @Override
           public Integer fold(Integer acc, Tuple2<Integer, Integer> value) throws Exception{
            count++;
            round_tmp++;

            //acc+=value.f1;
            if(count<=pane)
            {
                f1_value+=value.f1;
            }

            //if(round_tmp%slide==0)
            if(count>=pane)
            {
                round++;
                if(round==num_slide)
                    round=0;
                agg.put(round, new Tuple2<>(value.f0,f1_value));
                count=0;
                f1_value=0;
                if(round_tmp >= slide)
                {
                    round_tmp=0;
                    Integer result=0;
                    for(Map.Entry<Integer, Tuple2<Integer, Integer>> entry : agg.entrySet())
                    {
                        result += entry.getValue().f1;
                    }
                    acc = result;
                }
            }
               return acc;
           }
        });//.print();//.writeAsText("/Users/bousavong/Desktop/test/text/DEB12/pane.txt");//;//.print();//.writeAsText("/Users/bousavong/Desktop/test/text/DEB12/answer/pane");//.print();

        env.execute("Word Count Example");
        tEnd = System.currentTimeMillis();
        elapsedSeconds = (tEnd - tStart) / 1000.0;
        double taskCpuTimeNano    = (getCpuTime( ) - startCpuTimeNano) / 1000000000.0;
        double taskUserTimeNano    = (getUserTime( ) - startUserTimeNano) / 1000000000.0;
        double taskSystemTimeNano  = (getSystemTime( ) - startSystemTimeNano) / 1000000000.0;
        System.out.println("taskCpuTimeNano:"+taskCpuTimeNano);
        System.out.println("taskUserTimeNano:"+taskUserTimeNano);
        System.out.println("taskSystemTimeNano:"+taskSystemTimeNano);
        System.out.println("Time:"+elapsedSeconds);
        System.out.println("Finish");
    }
    public static class LineSplitter implements FlatMapFunction<String, Tuple11<Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer>> {
        @Override
        public void flatMap(String line, Collector<Tuple11<Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer>> out) {
            String[] cells = line.split("\\s+");
            out.collect(new Tuple11<>(1, Integer.parseInt(cells[1]), Integer.parseInt(cells[2]), Integer.parseInt(cells[3]), Integer.parseInt(cells[4]), Integer.parseInt(cells[5]), Integer.parseInt(cells[6]), Integer.parseInt(cells[7]), Integer.parseInt(cells[8]), Integer.parseInt(cells[9]), Integer.parseInt(cells[10])));
        }
    }

    public static class LineSplitter2 implements FlatMapFunction<String, Tuple2<Integer, Integer>> {
        @Override
        public void flatMap(String line, Collector<Tuple2<Integer, Integer>> out) {
            String[] cells = line.split("\\s+");
            //out.collect(new Tuple2<>(Integer.parseInt(cells[1]), Integer.parseInt(cells[2])));
            out.collect(new Tuple2<>(1, Integer.parseInt(cells[2])));
        }
    }
    private static int gcdThing(int a, int b) {
        BigInteger b1 = BigInteger.valueOf(a);
        BigInteger b2 = BigInteger.valueOf(b);
        BigInteger gcd = b1.gcd(b2);
        return gcd.intValue();
    }
    
    
        // Get CPU time in nanoseconds. 
public static long getCpuTime( ) {
    ThreadMXBean bean = ManagementFactory.getThreadMXBean( );
    return bean.isCurrentThreadCpuTimeSupported( ) ?
        bean.getCurrentThreadCpuTime( ) : 0L;
}
 
// Get user time in nanoseconds. 
public static long getUserTime( ) {
    ThreadMXBean bean = ManagementFactory.getThreadMXBean( );
    return bean.isCurrentThreadCpuTimeSupported( ) ?
        bean.getCurrentThreadUserTime( ) : 0L;
}

// Get system time in nanoseconds. 
public static long getSystemTime( ) {
    ThreadMXBean bean = ManagementFactory.getThreadMXBean( );
    return bean.isCurrentThreadCpuTimeSupported( ) ?
        (bean.getCurrentThreadCpuTime( ) - bean.getCurrentThreadUserTime( )) : 0L;
}
}
//Panes Approach ========================End 201796=============================
//Panes Approach ========================End 201796=============================
//Panes Approach ========================End 201796=============================
//Panes Approach ========================End 201796=============================
//Panes Approach ========================End 201796=============================
//Panes Approach ========================End 201796=============================
*/



/*
//Cutty-slicing Approach ========================Begin 201796===========================
//Cutty-slicing Approach ========================Begin 201796===========================
//Cutty-slicing Approach ========================Begin 201796===========================
//Cutty-slicing Approach ========================Begin 201796===========================
//Cutty-slicing Approach ========================Begin 201796===========================
//Cutty-slicing Approach ========================Begin 201796===========================
public class Sum {
    public static void main(String[] args) throws Exception{
        // TODO code application logic here
        final StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        //env.setStreamTimeCharacteristic(TimeCharacteristic.ProcessingTime);
        //env.setParallelism(1);
        DataStream<Tuple2<Integer,Integer>> datastream = env.readTextFile("/home/savong/デスクトップ/DEBS2012_Dataset/DEBS2012_129millions.txt")//DEB12/DEBS2012-ChallengeData.txt") //5000000.txt //50000.txt
        .flatMap(new LineSplitter2());
        
        long startCpuTimeNano = getCpuTime( );
        long startSystemTimeNano = getSystemTime( );
        long startUserTimeNano   = getUserTime( );
        long tStart= System.currentTimeMillis();//=0;// = System.currentTimeMillis();
        long tEnd=0;
        double elapsedSeconds=0.0;
        

        int range = 10000000;
                int slide = 1;
                int f2 = range%slide;
                int f1 = slide - f2;
                int num_slide = range/slide;
                datastream
                .keyBy(0)
                .countWindow(range,slide).trigger(PurgingTrigger.of(CountTrigger.of(slide)))//.evictor(CountEvictor.of(slide))
                .fold(new Integer (0), new FoldFunction<Tuple2<Integer, Integer>, Integer>() {
                   HashMap<Integer, Tuple2<Integer, Integer>> agg = new HashMap<Integer, Tuple2<Integer, Integer>>();
                   int f1_value=0;
                   int f2_value=0;
                   int count=0;
                   int round_tmp=0;
                   int round=0;
                   @Override
                   public Integer fold(Integer acc, Tuple2<Integer, Integer> value) throws Exception{
                    count++;
                    round_tmp++;
                    
                    //acc+=value.f1;
                    if(count<=f1)
                    {
                        f1_value+=value.f1;
                    }
                    else if (count <= f2+f1)
                    {
                        f2_value+=value.f1;
                    }
                    
                    //if(round_tmp%slide==0)
                    if(round_tmp>=slide)
                    {
                        round_tmp=0;
                        round++;
                        if(agg.containsKey(round-1))
                            agg.put(round-1, new Tuple2<>(value.f0,f1_value+agg.get(round-1).f1));
                        else
                            agg.put(round-1, new Tuple2<>(value.f0,f1_value));
                        if(round==num_slide+1)
                            round=0;
                        agg.put(round, new Tuple2<>(value.f0,f2_value));
                        count=0;
                        f1_value=0;
                        f2_value=0;
                    Integer result=0;
                    
                    for(Map.Entry<Integer, Tuple2<Integer, Integer>> entry : agg.entrySet())
                    {
                        result += entry.getValue().f1;
                    }
                    acc = result;
                    }
                       return acc;
                   }
                });//.print();//.writeAsText("/Users/bousavong/Desktop/test/text/DEB12/cutty.txt");//.print();

        env.execute("Word Count Example");
        tEnd = System.currentTimeMillis();
        elapsedSeconds = (tEnd - tStart) / 1000.0;
        double taskCpuTimeNano    = (getCpuTime( ) - startCpuTimeNano) / 1000000000.0;
        double taskUserTimeNano    = (getUserTime( ) - startUserTimeNano) / 1000000000.0;
        double taskSystemTimeNano  = (getSystemTime( ) - startSystemTimeNano) / 1000000000.0;
        System.out.println("taskCpuTimeNano:"+taskCpuTimeNano);
        System.out.println("taskUserTimeNano:"+taskUserTimeNano);
        System.out.println("taskSystemTimeNano:"+taskSystemTimeNano);
        System.out.println("Time:"+elapsedSeconds);
        System.out.println("Finish");
    }
    public static class LineSplitter implements FlatMapFunction<String, Tuple11<Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer>> {
        @Override
        public void flatMap(String line, Collector<Tuple11<Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer>> out) {
            String[] cells = line.split("\\s+");
            out.collect(new Tuple11<>(1, Integer.parseInt(cells[1]), Integer.parseInt(cells[2]), Integer.parseInt(cells[3]), Integer.parseInt(cells[4]), Integer.parseInt(cells[5]), Integer.parseInt(cells[6]), Integer.parseInt(cells[7]), Integer.parseInt(cells[8]), Integer.parseInt(cells[9]), Integer.parseInt(cells[10])));
        }
    }

    public static class LineSplitter2 implements FlatMapFunction<String, Tuple2<Integer, Integer>> {
        @Override
        public void flatMap(String line, Collector<Tuple2<Integer, Integer>> out) {
            String[] cells = line.split("\\s+");
            //out.collect(new Tuple2<>(Integer.parseInt(cells[1]), Integer.parseInt(cells[2])));
            out.collect(new Tuple2<>(1, Integer.parseInt(cells[2])));
        }
    }
    
     // Get CPU time in nanoseconds. 
public static long getCpuTime( ) {
    ThreadMXBean bean = ManagementFactory.getThreadMXBean( );
    return bean.isCurrentThreadCpuTimeSupported( ) ?
        bean.getCurrentThreadCpuTime( ) : 0L;
}
 
// Get user time in nanoseconds. 
public static long getUserTime( ) {
    ThreadMXBean bean = ManagementFactory.getThreadMXBean( );
    return bean.isCurrentThreadCpuTimeSupported( ) ?
        bean.getCurrentThreadUserTime( ) : 0L;
}

// Get system time in nanoseconds. 
public static long getSystemTime( ) {
    ThreadMXBean bean = ManagementFactory.getThreadMXBean( );
    return bean.isCurrentThreadCpuTimeSupported( ) ?
        (bean.getCurrentThreadCpuTime( ) - bean.getCurrentThreadUserTime( )) : 0L;
}
}
//Cutty-slicing Approach ========================End 201796=============================
//Cutty-slicing Approach ========================End 201796=============================
//Cutty-slicing Approach ========================End 201796=============================
//Cutty-slicing Approach ========================End 201796=============================
//Cutty-slicing Approach ========================End 201796=============================
//Cutty-slicing Approach ========================End 201796=============================
*/






/*
//Paired Window Approach ====================Begin 201796====================
//Paired Window Approach ====================Begin 201796====================
//Paired Window Approach ====================Begin 201796====================
//Paired Window Approach ====================Begin 201796====================
//Paired Window Approach ====================Begin 201796====================
//Paired Window Approach ====================Begin 201796====================
public class Sum {
    public static void main(String[] args) throws Exception{
        // TODO code application logic here
        final StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        //env.setStreamTimeCharacteristic(TimeCharacteristic.ProcessingTime);
        //env.setParallelism(1);
        DataStream<Tuple2<Integer,Integer>> datastream = env.readTextFile("/home/savong/デスクトップ/DEBS2012_Dataset/DEBS2012_129millions.txt")//DEB12/DEBS2012-ChallengeData.txt") //5000000.txt //50000.txt
        .flatMap(new LineSplitter2());
        
        long startCpuTimeNano = getCpuTime( );
        long startSystemTimeNano = getSystemTime( );
        long startUserTimeNano   = getUserTime( );
        long tStart= System.currentTimeMillis();//=0;// = System.currentTimeMillis();
        long tEnd=0;
        double elapsedSeconds=0.0;
        

        int range = 10000000;
            int slide = 1;
            int f2 = range%slide;
            int f1 = slide - f2;
            int num_slide;
            if(f2==0)
                num_slide = 2*(range/slide);
            else
                num_slide = 2* (int) Math.floor(range/(float)slide)+1;
            //int num_slide = 2* (int) Math.floor(range/(float)slide);
                        
            datastream
            .keyBy(0)
            .countWindow(range,slide).trigger(PurgingTrigger.of(CountTrigger.of(slide)))//.evictor(CountEvictor.of(slide))
            .fold(new Integer (0), new FoldFunction<Tuple2<Integer, Integer>, Integer>() {
               HashMap<Integer, Tuple2<Integer, Integer>> agg = new HashMap<Integer, Tuple2<Integer, Integer>>();
               int f1_value=0;
               int f2_value=0;
               int count=0;
               int round_tmp=0;
               int round=0;
               @Override
               public Integer fold(Integer acc, Tuple2<Integer, Integer> value) throws Exception{
                count++;
                round_tmp++;

                //acc+=value.f1;
                if(count<=f1)
                {
                    f1_value+=value.f1;
                }
                else if (count <= f2+f1)
                {
                    f2_value+=value.f1;
                }

                //if(round_tmp%slide==0)
                if(round_tmp>=slide)
                {
                    round_tmp=0;
                    round++;
                    agg.put(round, new Tuple2<>(value.f0,f1_value));
                    if(round==num_slide)
                        round=0;
                    round++;
                    agg.put(round, new Tuple2<>(value.f0,f2_value));
                    if(round==num_slide)
                        round=0;
                    count=0;
                    f1_value=0;
                    f2_value=0;
                Integer result=0;

                for(Map.Entry<Integer, Tuple2<Integer, Integer>> entry : agg.entrySet())
                {
                    result += entry.getValue().f1;
                }
                acc = result;
                }
                   return acc;
               }
            });//.print();//.writeAsText("/Users/bousavong/Desktop/test/text/DEB12/pair.txt");//.print();

        env.execute("Word Count Example");
        tEnd = System.currentTimeMillis();
        elapsedSeconds = (tEnd - tStart) / 1000.0;
        double taskCpuTimeNano    = (getCpuTime( ) - startCpuTimeNano) / 1000000000.0;
        double taskUserTimeNano    = (getUserTime( ) - startUserTimeNano) / 1000000000.0;
        double taskSystemTimeNano  = (getSystemTime( ) - startSystemTimeNano) / 1000000000.0;
        System.out.println("taskCpuTimeNano:"+taskCpuTimeNano);
        System.out.println("taskUserTimeNano:"+taskUserTimeNano);
        System.out.println("taskSystemTimeNano:"+taskSystemTimeNano);
        System.out.println("Time:"+elapsedSeconds);
        System.out.println("Finish");
    }
    public static class LineSplitter implements FlatMapFunction<String, Tuple11<Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer>> {
        @Override
        public void flatMap(String line, Collector<Tuple11<Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer>> out) {
            String[] cells = line.split("\\s+");
            out.collect(new Tuple11<>(1, Integer.parseInt(cells[1]), Integer.parseInt(cells[2]), Integer.parseInt(cells[3]), Integer.parseInt(cells[4]), Integer.parseInt(cells[5]), Integer.parseInt(cells[6]), Integer.parseInt(cells[7]), Integer.parseInt(cells[8]), Integer.parseInt(cells[9]), Integer.parseInt(cells[10])));
        }
    }

    public static class LineSplitter2 implements FlatMapFunction<String, Tuple2<Integer, Integer>> {
        @Override
        public void flatMap(String line, Collector<Tuple2<Integer, Integer>> out) {
            String[] cells = line.split("\\s+");
            //out.collect(new Tuple2<>(Integer.parseInt(cells[1]), Integer.parseInt(cells[2])));
            out.collect(new Tuple2<>(1, Integer.parseInt(cells[2])));
        }
    }
    
            // Get CPU time in nanoseconds. 
public static long getCpuTime( ) {
    ThreadMXBean bean = ManagementFactory.getThreadMXBean( );
    return bean.isCurrentThreadCpuTimeSupported( ) ?
        bean.getCurrentThreadCpuTime( ) : 0L;
}
 
// Get user time in nanoseconds. 
public static long getUserTime( ) {
    ThreadMXBean bean = ManagementFactory.getThreadMXBean( );
    return bean.isCurrentThreadCpuTimeSupported( ) ?
        bean.getCurrentThreadUserTime( ) : 0L;
}

// Get system time in nanoseconds. 
public static long getSystemTime( ) {
    ThreadMXBean bean = ManagementFactory.getThreadMXBean( );
    return bean.isCurrentThreadCpuTimeSupported( ) ?
        (bean.getCurrentThreadCpuTime( ) - bean.getCurrentThreadUserTime( )) : 0L;
}
}
//Paired Window Approach ====================End 201796====================
//Paired Window Approach ====================End 201796====================
//Paired Window Approach ====================End 201796====================
//Paired Window Approach ====================End 201796====================
//Paired Window Approach ====================End 201796====================
//Paired Window Approach ====================End 201796====================
*/




/*
//FlatFat-Cutty-slicing Approach ========================Begin 201796===========================
//FlatFat-Cutty-slicing Approach ========================Begin 201796===========================
//FlatFat-Cutty-slicing Approach ========================Begin 201796===========================
//FlatFat-Cutty-slicing Approach ========================Begin 201796===========================
//FlatFat-Cutty-slicing Approach ========================Begin 201796===========================
//FlatFat-Cutty-slicing Approach ========================Begin 201796===========================
public class Sum {
    public static void main(String[] args) throws Exception{
        // TODO code application logic here
        final StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        //env.setStreamTimeCharacteristic(TimeCharacteristic.ProcessingTime);
        //env.setParallelism(1);
        DataStream<Tuple2<Integer,Integer>> datastream = env.readTextFile("/home/savong/デスクトップ/DEBS2012_Dataset/DEBS2012_129millions.txt")//DEB12/DEBS2012-ChallengeData.txt") //5000000.txt //50000.txt
        .flatMap(new LineSplitter2());
        
        long startCpuTimeNano = getCpuTime( );
        long startSystemTimeNano = getSystemTime( );
        long startUserTimeNano   = getUserTime( );

        long tStart= System.currentTimeMillis();//=0;// = System.currentTimeMillis();
        long tEnd=0;
        double elapsedSeconds=0.0;
        

        int range = 10000000;
                int slide = 1;
                int f2 = range%slide;
                int f1 = slide - f2;
                if(f2==0)
                {
                    int num_slide = range/slide;
                    Node Tree = BST(num_slide);
                    datastream
                    .keyBy(0)
                    .countWindow(range,slide).trigger(PurgingTrigger.of(CountTrigger.of(slide)))//.evictor(CountEvictor.of(slide))
                    .fold(new Integer (0), new FoldFunction<Tuple2<Integer, Integer>, Integer>() {
                       int f1_value=0;
                       int f2_value=0;
                       int count=0;
                       int round_tmp=0;
                       int round=0;
                       @Override
                       public Integer fold(Integer acc, Tuple2<Integer, Integer> value) throws Exception{
                        count++;
                        round_tmp++;

                        //acc+=value.f1;
                        if(count<=f1)
                        {
                            f1_value+=value.f1;
                        }

                        //if(round_tmp%slide==0)
                        if(round_tmp>=slide)
                        {
                            round_tmp=0;
                            round++;
                            if(round==num_slide+1)
                               round=1;
                            insert(Tree, round, f1_value, 1);                            
                            count=0;
                            f1_value=0;
                        Integer result=(int)Tree.aggregating;
                        acc = result;
                        }
                        return acc;
                       }
                    });//.print();//.writeAsText("/Users/bousavong/Desktop/test/text/DEB12/flatfat.txt");//.print();
                }
                else
                {
                    int num_slide = range/slide+1;
                    Node Tree = BST(num_slide);
                    datastream
                    .keyBy(0)
                    .countWindow(range,slide).trigger(PurgingTrigger.of(CountTrigger.of(slide)))//.evictor(CountEvictor.of(slide))
                    .fold(new Integer (0), new FoldFunction<Tuple2<Integer, Integer>, Integer>() {
                       int f1_value=0;
                       int f2_value=0;
                       int count=0;
                       int round_tmp=0;
                       int round=0;
                       @Override
                       public Integer fold(Integer acc, Tuple2<Integer, Integer> value) throws Exception{
                        count++;
                        round_tmp++;

                        //acc+=value.f1;
                        if(count<=f1)
                        {
                            f1_value+=value.f1;
                        }
                        else if (count <= f2+f1)
                        {
                            f2_value+=value.f1;
                        }

                        //if(round_tmp%slide==0)
                        if(round_tmp>=slide)
                        {
                            round_tmp=0;
                            round++;
                            insert2(Tree, round, f1_value, 1);
                            if(round==num_slide)
                               round=0;
                            insert2(Tree, round+1, f2_value, 2);
                            count=0;
                            f1_value=0;
                            f2_value=0;
                        Integer result=(int)Tree.aggregating;
                        acc = result;
                        }
                           return acc;
                       }
                    });//.print();//;//.writeAsText("/Users/bousavong/Desktop/test/text/DEB12/flatfat.txt");//.print();
                }

        env.execute("Word Count Example");
        tEnd = System.currentTimeMillis();
        elapsedSeconds = (tEnd - tStart) / 1000.0;
        double taskCpuTimeNano    = (getCpuTime( ) - startCpuTimeNano) / 1000000000.0;
        double taskUserTimeNano    = (getUserTime( ) - startUserTimeNano) / 1000000000.0;
        double taskSystemTimeNano  = (getSystemTime( ) - startSystemTimeNano) / 1000000000.0;
        System.out.println("taskCpuTimeNano:"+taskCpuTimeNano);
        System.out.println("taskUserTimeNano:"+taskUserTimeNano);
        System.out.println("taskSystemTimeNano:"+taskSystemTimeNano);
        System.out.println("Time:"+elapsedSeconds);
        System.out.println("Finish");
    }
    public static class LineSplitter implements FlatMapFunction<String, Tuple11<Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer>> {
        @Override
        public void flatMap(String line, Collector<Tuple11<Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer>> out) {
            String[] cells = line.split("\\s+");
            out.collect(new Tuple11<>(1, Integer.parseInt(cells[1]), Integer.parseInt(cells[2]), Integer.parseInt(cells[3]), Integer.parseInt(cells[4]), Integer.parseInt(cells[5]), Integer.parseInt(cells[6]), Integer.parseInt(cells[7]), Integer.parseInt(cells[8]), Integer.parseInt(cells[9]), Integer.parseInt(cells[10])));
        }
    }

    public static class LineSplitter2 implements FlatMapFunction<String, Tuple2<Integer, Integer>> {
        @Override
        public void flatMap(String line, Collector<Tuple2<Integer, Integer>> out) {
            String[] cells = line.split("\\s+");
            //out.collect(new Tuple2<>(Integer.parseInt(cells[1]), Integer.parseInt(cells[2])));
            out.collect(new Tuple2<>(1, Integer.parseInt(cells[2])));
        }
    }
    //f1!=0, f20=0
        public static void insert(Node node, double tosearch, double aggregate, int f1f2) {
            //temperarily load
            ArrayList<Node> Tree_tmp = new ArrayList<>();
            for(int k=0;k<50;k++)
            {
                Node tmp=null;
                Tree_tmp.add(k, tmp);
            }
            //temperarily load
            if (tosearch < node.value) {
            if (node.left != null) {
                insert(node.left, tosearch, aggregate, f1f2);
                node.aggregating = node.left.aggregating+node.right.aggregating;
                }
            } else if (tosearch > node.value) {
                if (node.right != null) {
                    insert(node.right, tosearch, aggregate, f1f2);
                    node.aggregating = node.left.aggregating+node.right.aggregating;
                }
            }
            else
            {
                node.aggregating = aggregate;
            }
                
        }
        //f1!=, f2==0;

             //f1!=0, f2!=0
        public static void insert2(Node node, double tosearch, double aggregate, int f1f2) {
            if (tosearch < node.value) {
            if (node.left != null) {
                insert2(node.left, tosearch, aggregate, f1f2);
                node.aggregating = node.left.aggregating+node.right.aggregating;
                }
            } else if (tosearch > node.value) {
                if (node.right != null) {
                    insert2(node.right, tosearch, aggregate, f1f2);
                    node.aggregating = node.left.aggregating+node.right.aggregating;
                }
            }
            else
            {
                if(f1f2==1) //if f1_value, sum
                    node.aggregating += aggregate;
                else //if f2_value, overwrite
                    node.aggregating = aggregate;
            }
                
        }
        //f1!=, f2!=0;
        
        public static class Node implements Serializable
        {
            Node left;
            Node right;
            double value;
            double aggregating;
            double biggest_leaf_node;
            double smallest_leaf_node;
            public Node(double value) {
                this.value = value;
            }
        }
        static Node BST(Integer num_slide)
        {
            Node Tree;
            HashMap<Integer, Node> Leaf_nodes = new HashMap<>();
            Node tree = new Node(0);
            for(int i=1;i<=num_slide;i++)
            {
                Node level_node = new Node(i);
                level_node.biggest_leaf_node = i;
                level_node.smallest_leaf_node = i;
                Leaf_nodes.put(i, level_node);
            }
            
            while(true)
            {
                HashMap<Integer, Node> Leaf_nodes_tmp = new HashMap<>();
                for(int i=1;i<=Leaf_nodes.size();i++)
                {
                    if(i%2==1)//(k==1)
                    {
                        if(i<Leaf_nodes.size())
                        {
                            Node tmp1 = new Node(0);
                            tmp1.left= Leaf_nodes.get(i);
                            tmp1.value+=Leaf_nodes.get(i).value;
                            tmp1.biggest_leaf_node = Leaf_nodes.get(i).biggest_leaf_node;
                            tmp1.smallest_leaf_node = Leaf_nodes.get(i).smallest_leaf_node;
                            Leaf_nodes_tmp.put(Leaf_nodes_tmp.size()+1, tmp1);
                        }
                        else
                        {
                            Leaf_nodes_tmp.put(Leaf_nodes_tmp.size()+1, Leaf_nodes.get(i));
                        }
                    }
                    else// if(k==2)
                    {
                        Leaf_nodes_tmp.get(Leaf_nodes_tmp.size()).right=Leaf_nodes.get(i);//tmp1;
                        //Leaf_nodes_tmp.get(Leaf_nodes_tmp.size()).value =(Leaf_nodes_tmp.get(Leaf_nodes_tmp.size()).value+Leaf_nodes.get(i).value)/2;
                        Leaf_nodes_tmp.get(Leaf_nodes_tmp.size()).value =(Leaf_nodes_tmp.get(Leaf_nodes_tmp.size()).biggest_leaf_node+Leaf_nodes.get(i).smallest_leaf_node)/2;
                        Leaf_nodes_tmp.get(Leaf_nodes_tmp.size()).biggest_leaf_node = Leaf_nodes.get(i).biggest_leaf_node;
                        Leaf_nodes_tmp.get(Leaf_nodes_tmp.size()).smallest_leaf_node = Leaf_nodes_tmp.get(Leaf_nodes_tmp.size()).smallest_leaf_node;
                    }   
                }
                Leaf_nodes = Leaf_nodes_tmp;
                if(Leaf_nodes.size()==1)
                {
                    Tree=Leaf_nodes.get(1);
                    break;
                } 
            }
            return Tree;
        }
        
        // Get CPU time in nanoseconds. 
public static long getCpuTime( ) {
    ThreadMXBean bean = ManagementFactory.getThreadMXBean( );
    return bean.isCurrentThreadCpuTimeSupported( ) ?
        bean.getCurrentThreadCpuTime( ) : 0L;
}
 
// Get user time in nanoseconds. 
public static long getUserTime( ) {
    ThreadMXBean bean = ManagementFactory.getThreadMXBean( );
    return bean.isCurrentThreadCpuTimeSupported( ) ?
        bean.getCurrentThreadUserTime( ) : 0L;
}

// Get system time in nanoseconds.
public static long getSystemTime( ) {
    ThreadMXBean bean = ManagementFactory.getThreadMXBean( );
    return bean.isCurrentThreadCpuTimeSupported( ) ?
        (bean.getCurrentThreadCpuTime( ) - bean.getCurrentThreadUserTime( )) : 0L;
}
}
//FlatFat-Cutty-slicing Approach ========================End 201796=============================
//FlatFat-Cutty-slicing Approach ========================End 201796=============================
//FlatFat-Cutty-slicing Approach ========================End 201796=============================
//FlatFat-Cutty-slicing Approach ========================End 201796=============================
//FlatFat-Cutty-slicing Approach ========================End 201796=============================
//FlatFat-Cutty-slicing Approach ========================End 201796=============================
*/











/*
//L-BiX Approach ========================Begin 201796===========================
//L-BiX Approach ========================Begin 201796===========================
//L-BiX Approach ========================Begin 201796===========================
//L-BiX Approach ========================Begin 201796===========================
//L-BiX Approach ========================Begin 201796===========================
//L-BiX Approach ========================Begin 201796===========================
public class Sum {
    public static void main(String[] args) throws Exception{
        // TODO code application logic here
        final StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        //env.setStreamTimeCharacteristic(TimeCharacteristic.ProcessingTime);
        //env.setParallelism(1);
        
      
        

        
        DataStream<Tuple2<Integer,Integer>> datastream = env.readTextFile("/home/savong/デスクトップ/DEBS2012_Dataset/DEBS2012_129millions.txt")//DEB12/DEBS2012-ChallengeData.txt") //5000000.txt //50000.txt
        .flatMap(new LineSplitter2());
        
        long startCpuTimeNano = getCpuTime( );
        long startSystemTimeNano = getSystemTime( );
        long startUserTimeNano   = getUserTime( );
        long tStart= System.currentTimeMillis();//=0;// = System.currentTimeMillis();
        long tEnd=0;
        double elapsedSeconds=0.0;

        int range = 1000000000;
                int slide = 1;
                int f2 = range%slide;
                int f1 = slide - f2;
                if(f2==0)
                {
                int num_slide = range/slide;
                
                double[] tree_aggregation = new double[num_slide]; 

                datastream
                .keyBy(0)
                .countWindow(range,slide).trigger(PurgingTrigger.of(CountTrigger.of(slide)))//.evictor(CountEvictor.of(slide))
                .fold(new Integer (0), new FoldFunction<Tuple2<Integer, Integer>, Integer>() {
                   int f1_value=0;
                   int count=0;
                   int round_tmp=0;
                   int round=0;
                   @Override
                   public Integer fold(Integer acc, Tuple2<Integer, Integer> value) throws Exception{
                        count++;
                        round_tmp++;

                        if(count<=f1)
                        {
                            f1_value+=value.f1;
                        }

                        //if(round_tmp%slide==0)
                        if(round_tmp>=slide)
                        {
                            double results=0.0;
                            double forward_aggregate = tree_aggregation[round]+f1_value;
                            if(round<=num_slide-2)
                            {
                                //Get the result by combining the pair forward-aggregating node and backward-aggregating node                            
                                results = forward_aggregate + tree_aggregation[round+1];
                                tree_aggregation[round] = f1_value;
                                tree_aggregation[round+1]= forward_aggregate;
                            }
                            else
                            {
                                results = forward_aggregate;
                                tree_aggregation[round]= f1_value;
                                //compute all backward-aggregating nodes when right-most node is visited
                                for(int k=num_slide-2;k>0;k--)
                                {
                                    //Tree.get(k).backward_aggregating = Tree.get(k).backward_aggregating+Tree.get(k+1).backward_aggregating;
                                    tree_aggregation[k]= tree_aggregation[k+1]+tree_aggregation[k];
                                }
                                tree_aggregation[0]= 0.0;
                            }
                            count=0;
                            f1_value=0;
                            round++;
                            round_tmp=0;
                            if(round==num_slide)
                               round=0;
                        //Integer result=0;//(int)Tree.aggregating;
                        acc = (int)results;
                        }
                        return acc;
                   }
                });//.print();//.writeAsText("/Users/bousavong/Desktop/test/text/DEB12/bidirection.txt");//.print();
                }
                else
                {
                int num_slide = range/slide+1;
                double[] tree_aggregation = new double[num_slide];                 

                datastream
                .keyBy(0)
                .countWindow(range,slide).trigger(PurgingTrigger.of(CountTrigger.of(slide)))//.evictor(CountEvictor.of(slide))
                .fold(new Integer (0), new FoldFunction<Tuple2<Integer, Integer>, Integer>() {
                   int f1_value=0;
                   int f2_value=0;
                   int count=0;
                   int round_tmp=0;
                   int round=0;
                   @Override
                   public Integer fold(Integer acc, Tuple2<Integer, Integer> value) throws Exception{
                        count++;
                        round_tmp++;

                        if(count<=f1)
                        {
                            f1_value+=value.f1;
                        }
                        else if (count <= f2+f1)
                        {
                            f2_value+=value.f1;
                        }

                        if(round_tmp>=slide)
                        {
                            double forward_aggregate = tree_aggregation[round]+f1_value;
                            if(round<=num_slide-2)
                            {
                                //Get the result by combining the pair forward-aggregating node and backward-aggregating node                            
                                tree_aggregation[round]= forward_aggregate;
                                tree_aggregation[round+1]= f1_value+tree_aggregation[round+1];
                            }
                            else
                            {
                                tree_aggregation[round]= forward_aggregate;
                                //compute all backward-aggregating nodes when right-most node is visited
                                for(int k=num_slide-2;k>0;k--)
                                {
                                    tree_aggregation[k]= tree_aggregation[k+1]+tree_aggregation[k];
                                }
                                tree_aggregation[0]= 0.0;
                            }
                            round++;
                            if(round==num_slide)
                               round=0;
                            double results=0.0;
                            double forward_aggregate2 = tree_aggregation[round]+f2_value;
                            
                            if(round<=num_slide-2)
                            {
                                //Get the result by combining the pair forward-aggregating node and backward-aggregating node                            
                                results = forward_aggregate2 + tree_aggregation[round+1];
                                tree_aggregation[round]= f2_value;
                                tree_aggregation[round+1]= forward_aggregate2;
                            }
                            else
                            {
                                results = forward_aggregate2;
                                tree_aggregation[round]= f2_value;
                            }
                            count=0;
                            f1_value=0;
                            f2_value=0;
                            round_tmp=0;
                        acc = (int)results;
                        }
                        return acc;
                   }
                });//.print();//.writeAsText("/Users/bousavong/Desktop/test/text/DEB12/bidirection.txt");//.print();
                }
        env.execute("Word Count Example");
        tEnd = System.currentTimeMillis();
        elapsedSeconds = (tEnd - tStart) / 1000.0;
        double taskCpuTimeNano    = (getCpuTime( ) - startCpuTimeNano) / 1000000000.0;
        double taskUserTimeNano    = (getUserTime( ) - startUserTimeNano) / 1000000000.0;
        double taskSystemTimeNano  = (getSystemTime( ) - startSystemTimeNano) / 1000000000.0;
        System.out.println("taskCpuTimeNano:"+taskCpuTimeNano);
        System.out.println("taskUserTimeNano:"+taskUserTimeNano);
        System.out.println("taskSystemTimeNano:"+taskSystemTimeNano);
        System.out.println("Time:"+elapsedSeconds);
        System.out.println("Finish");
    }
    public static class LineSplitter implements FlatMapFunction<String, Tuple11<Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer>> {
        @Override
        public void flatMap(String line, Collector<Tuple11<Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer>> out) {
            String[] cells = line.split("\\s+");
            out.collect(new Tuple11<>(1, Integer.parseInt(cells[1]), Integer.parseInt(cells[2]), Integer.parseInt(cells[3]), Integer.parseInt(cells[4]), Integer.parseInt(cells[5]), Integer.parseInt(cells[6]), Integer.parseInt(cells[7]), Integer.parseInt(cells[8]), Integer.parseInt(cells[9]), Integer.parseInt(cells[10])));
        }
    }

    public static class LineSplitter2 implements FlatMapFunction<String, Tuple2<Integer, Integer>> {
        @Override
        public void flatMap(String line, Collector<Tuple2<Integer, Integer>> out) {
            String[] cells = line.split("\\s+");
            //out.collect(new Tuple2<>(Integer.parseInt(cells[1]), Integer.parseInt(cells[2])));
            out.collect(new Tuple2<>(1, Integer.parseInt(cells[2])));
        }
    }
    
    
        // Get CPU time in nanoseconds. 
public static long getCpuTime( ) {
    ThreadMXBean bean = ManagementFactory.getThreadMXBean( );
    return bean.isCurrentThreadCpuTimeSupported( ) ?
        bean.getCurrentThreadCpuTime( ) : 0L;
}
 
// Get user time in nanoseconds. 
public static long getUserTime( ) {
    ThreadMXBean bean = ManagementFactory.getThreadMXBean( );
    return bean.isCurrentThreadCpuTimeSupported( ) ?
        bean.getCurrentThreadUserTime( ) : 0L;
}

// Get system time in nanoseconds. 
public static long getSystemTime( ) {
    ThreadMXBean bean = ManagementFactory.getThreadMXBean( );
    return bean.isCurrentThreadCpuTimeSupported( ) ?
        (bean.getCurrentThreadCpuTime( ) - bean.getCurrentThreadUserTime( )) : 0L;
}
}
//L-BiX Approach ========================End 201796=============================
//L-BiX Approach ========================End 201796=============================
//L-BiX Approach ========================End 201796=============================
//L-BiX Approach ========================End 201796=============================
//L-BiX Approach ========================End 201796=============================
//L-BiX Approach ========================End 201796=============================
*/





//L-BiX-fast Approach ========================Begin 2018321===========================
//L-BiX-fast Approach ========================Begin 2018321===========================
//L-BiX-fast Approach ========================Begin 2018321===========================
//L-BiX-fast Approach ========================Begin 2018321===========================
//L-BiX-fast Approach ========================Begin 2018321===========================
//L-BiX-fast Approach ========================Begin 2018321===========================
public class Sum {
    public static void main(String[] args) throws Exception{
        // TODO code application logic here
        final StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        //env.setStreamTimeCharacteristic(TimeCharacteristic.ProcessingTime);
        //env.setParallelism(1);
                

        DataStream<Tuple2<Integer,Integer>> datastream = env.readTextFile("/home/savong/デスクトップ/DEBS2012_Dataset/DEBS2012_129millions.txt")//DEB12/DEBS2012-ChallengeData.txt") //5000000.txt //50000.txt
        .flatMap(new LineSplitter2());
        
        
long startCpuTimeNano = getCpuTime( );
long startSystemTimeNano = getSystemTime( );
long startUserTimeNano   = getUserTime( );
long tStart= System.currentTimeMillis();//=0;// = System.currentTimeMillis();
long tEnd=0;
Double elapsedSeconds=0.0;

        int range = 10000;
                int slide = 1;
                int f2 = range%slide;
                int f1 = slide - f2;
                if(f2==0)
                {
                int num_slide = range/slide;              
                Stack<Double> F = new Stack();
                Stack<Double> B = new Stack();

                datastream
                .keyBy(0)
                .countWindow(range,slide).trigger(PurgingTrigger.of(CountTrigger.of(slide)))//.evictor(CountEvictor.of(slide))
                .fold(new Integer (0), new FoldFunction<Tuple2<Integer, Integer>, Integer>() {
                   double f1_value=0;
                   int count=0;
                   int round_tmp=0;
                   int round=0;
                   @Override
                   public Integer fold(Integer acc, Tuple2<Integer, Integer> value) throws Exception{
                        count++;
                        round_tmp++;
                        if(count<=f1)
                        {
                            f1_value+=value.f1;
                        }
                        //if(round_tmp%slide==0)
                        if(round_tmp>=slide)
                        {
                            round++;
                            //insert
                            double Af =0;
                            if(B.isEmpty())
                                Af = f1_value;
                            else
                                Af = f1_value+B.pop();
                            B.push(f1_value);
                            if(B.size()<num_slide)
                                B.push(Af);
    
                            //result
                            double results=0.0;
                            if(!F.isEmpty())
                                results = Af+F.pop();
                            else
                                results = Af;

                            //pop
                            if(round >= num_slide)
                            {
                                //B.pop();
                                if(F.isEmpty())
                                {
                                    while(!B.isEmpty())
                                    {
                                        if(F.isEmpty())
                                            F.push(B.pop());
                                        else
                                            F.push(B.pop()+F.peek());
                                    }
                                    F.pop();
                                }
                                round=0;
                            }
                            


                        count=0;
                        f1_value=0;
                        round_tmp=0;      
                        acc = (int)results;
                        }
                        return acc;
                   }
                });//.print();//.writeAsText("/Users/bousavong/Desktop/test/text/DEB12/bidirection.txt");//.print();
                }
                else
                {
                Stack<Double> F = new Stack();
                Stack<Double> B = new Stack();

                int num_slide = range/slide+1;

                datastream
                .keyBy(0)
                .countWindow(range,slide).trigger(PurgingTrigger.of(CountTrigger.of(slide)))//.evictor(CountEvictor.of(slide))
                .fold(new Integer (0), new FoldFunction<Tuple2<Integer, Integer>, Integer>() {
                   double f1_value=0;
                   double f2_value=0;
                   int count=0;
                   int round_tmp=0;
                   int round=0;
                   @Override
                   public Integer fold(Integer acc, Tuple2<Integer, Integer> value) throws Exception{
                        count++;
                        round_tmp++;
                        if(count<=f1)
                        {
                            f1_value+=value.f1;
                        }
                        else if (count <= f2+f1)
                        {
                            f2_value+=value.f1;
                        }

                        //double forward_aggregate = tree_aggregation[round]+f1_value;
                        if(round_tmp>=slide)
                        {                            
                            //insert
                            double Af =0;
                            if(B.isEmpty())
                                Af = f1_value;
                            else
                                Af = f1_value+B.pop();
                            if(B.isEmpty())
                                B.push(f1_value);
                            else
                                B.push(f1_value+B.pop());

                            

                            round++;

                            
                            //pop
                            if(round >= num_slide)
                            {
                                //B.pop();
                                if(F.isEmpty())
                                {
                                    while(!B.isEmpty())
                                    {
                                        if(F.isEmpty())
                                            F.push(B.peek());
                                        else
                                            F.push(B.peek()+F.peek());
                                        B.pop();
                                    }
                                    F.pop();
                                }
                                round=0;
                            }
                                                        

                            //insert
                            double Af1 =0;
                            if(B.isEmpty())
                                Af1 = f2_value;
                            else
                                Af1 = f2_value+Af;
                            B.push(f2_value);
                            if(round<num_slide)
                                B.push(Af1);

                            
                            
                            
                            
                            
                            //result
                            double results=0.0;
                            if(!F.isEmpty())
                                results = Af1+F.pop();
                            else
                                results = Af1;

                            
   
                            
                            count=0;
                            f1_value=0;
                            f2_value=0;
                            round_tmp=0;
                        acc = (int)results;
                        }
                        return acc;
                   }
                });//.print();//.writeAsText("/Users/bousavong/Desktop/test/text/DEB12/bidirection.txt");//.print();
                }
        env.execute("Word Count Example");
        tEnd = System.currentTimeMillis();
        elapsedSeconds = (tEnd - tStart) / 1000.0;
        double taskCpuTimeNano    = (getCpuTime( ) - startCpuTimeNano) / 1000000000.0;
        double taskUserTimeNano    = (getUserTime( ) - startUserTimeNano) / 1000000000.0;
        double taskSystemTimeNano  = (getSystemTime( ) - startSystemTimeNano) / 1000000000.0;
        System.out.println("taskCpuTimeNano:"+taskCpuTimeNano);
        System.out.println("taskUserTimeNano:"+taskUserTimeNano);
        System.out.println("taskSystemTimeNano:"+taskSystemTimeNano);
        System.out.println("Time:"+elapsedSeconds);
        System.out.println("Finish");
    }
    public static class LineSplitter implements FlatMapFunction<String, Tuple11<Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer>> {
        @Override
        public void flatMap(String line, Collector<Tuple11<Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer>> out) {
            String[] cells = line.split("\\s+");
            out.collect(new Tuple11<>(1, Integer.parseInt(cells[1]), Integer.parseInt(cells[2]), Integer.parseInt(cells[3]), Integer.parseInt(cells[4]), Integer.parseInt(cells[5]), Integer.parseInt(cells[6]), Integer.parseInt(cells[7]), Integer.parseInt(cells[8]), Integer.parseInt(cells[9]), Integer.parseInt(cells[10])));
        }
    }

    public static class LineSplitter2 implements FlatMapFunction<String, Tuple2<Integer, Integer>> {
        @Override
        public void flatMap(String line, Collector<Tuple2<Integer, Integer>> out) {
            String[] cells = line.split("\\s+");
            //out.collect(new Tuple2<>(Integer.parseInt(cells[1]), Integer.parseInt(cells[2])));
            out.collect(new Tuple2<>(1, Integer.parseInt(cells[2])));
        }
    }
    
            // Get CPU time in nanoseconds. 
public static long getCpuTime( ) {
    ThreadMXBean bean = ManagementFactory.getThreadMXBean( );
    return bean.isCurrentThreadCpuTimeSupported( ) ?
        bean.getCurrentThreadCpuTime( ) : 0L;
}
 
// Get user time in nanoseconds. 
public static long getUserTime( ) {
    ThreadMXBean bean = ManagementFactory.getThreadMXBean( );
    return bean.isCurrentThreadCpuTimeSupported( ) ?
        bean.getCurrentThreadUserTime( ) : 0L;
}

// Get system time in nanoseconds. 
public static long getSystemTime( ) {
    ThreadMXBean bean = ManagementFactory.getThreadMXBean( );
    return bean.isCurrentThreadCpuTimeSupported( ) ?
        (bean.getCurrentThreadCpuTime( ) - bean.getCurrentThreadUserTime( )) : 0L;
}

}
//L-BiX-fast Approach ========================End 2018321=============================
//L-BiX-fast Approach ========================End 2018321=============================
//L-BiX-fast Approach ========================End 2018321=============================
//L-BiX-fast Approach ========================End 2018321=============================
//L-BiX-fast Approach ========================End 2018321=============================
//L-BiX-fast Approach ========================End 2018321=============================




/*
//(2nd Optimal, efficient)Bidirection-Tree Approach ========================Begin 201796===========================
//(2nd Optimal, efficient)Bidirection-Tree Approach ========================Begin 201796===========================
//(2nd Optimal, efficient)Bidirection-Tree Approach ========================Begin 201796===========================
//(2nd Optimal, efficient)Bidirection-Tree Approach ========================Begin 201796===========================
//(2nd Optimal, efficient)Bidirection-Tree Approach ========================Begin 201796===========================
//(2nd Optimal, efficient)Bidirection-Tree Approach ========================Begin 201796===========================
public class Sum {
    public static void main(String[] args) throws Exception{
        // TODO code application logic here
        final StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        //env.setStreamTimeCharacteristic(TimeCharacteristic.ProcessingTime);
        //env.setParallelism(1);
        
      
        
        DataStream<Tuple2<Integer,Integer>> datastream = env.readTextFile("/home/savong/デスクトップ/DEBS2012_Dataset/DEBS2012_129millions.txt")//DEB12/DEBS2012-ChallengeData.txt") //5000000.txt //50000.txt
        .flatMap(new LineSplitter2());
        
                long startCpuTimeNano = getCpuTime( );
        long startSystemTimeNano = getSystemTime( );
        long startUserTimeNano   = getUserTime( );
        long tStart= System.currentTimeMillis();//=0;// = System.currentTimeMillis();
        long tEnd=0;
        double elapsedSeconds=0.0;

        int range = 10000000;
                int slide = 1;
                int f2 = range%slide;
                int f1 = slide - f2;
                if(f2==0)
                {
                int num_slide = range/slide;
                
                ArrayList<Double> tree_aggregation = new ArrayList<>();
                for(int i=0;i<num_slide;i++)
                {
                    tree_aggregation.add(i, 0.0);
                }
                datastream
                .keyBy(0)
                .countWindow(range,slide).trigger(PurgingTrigger.of(CountTrigger.of(slide)))//.evictor(CountEvictor.of(slide))
                .fold(new Integer (0), new FoldFunction<Tuple2<Integer, Integer>, Integer>() {
                   int f1_value=0;
                   int count=0;
                   int round_tmp=0;
                   int round=0;
                   @Override
                   public Integer fold(Integer acc, Tuple2<Integer, Integer> value) throws Exception{
                        count++;
                        round_tmp++;

                        if(count<=f1)
                        {
                            f1_value+=value.f1;
                        }

                        //if(round_tmp%slide==0)
                        if(round_tmp>=slide)
                        {
                            double results=0.0;
                            double forward_aggregate = tree_aggregation.get(round)+f1_value;
                            if(round<=num_slide-2)
                            {
                                //Get the result by combining the pair forward-aggregating node and backward-aggregating node                            
                                results = forward_aggregate + tree_aggregation.get(round+1);
                                tree_aggregation.set(round, (double)f1_value);
                                tree_aggregation.set(round+1, forward_aggregate);
                            }
                            else
                            {
                                results = forward_aggregate;
                                tree_aggregation.set(round, (double)f1_value);
                                //compute all backward-aggregating nodes when right-most node is visited
                                for(int k=num_slide-2;k>0;k--)
                                {
                                    //Tree.get(k).backward_aggregating = Tree.get(k).backward_aggregating+Tree.get(k+1).backward_aggregating;
                                    tree_aggregation.set(k, tree_aggregation.get(k+1)+tree_aggregation.get(k));
                                }
                                tree_aggregation.set(0, 0.0);
                            }
                            count=0;
                            f1_value=0;
                            round++;
                            round_tmp=0;
                            if(round==num_slide)
                               round=0;
                        //Integer result=0;//(int)Tree.aggregating;
                        acc = (int)results;
                        }
                        return acc;
                   }
                });//.print();//.writeAsText("/Users/bousavong/Desktop/test/text/DEB12/bidirection.txt");//.print();
                }
                else
                {
                int num_slide = range/slide+1;
                ArrayList<Double> tree_aggregation = new ArrayList<>();
                for(int i=0;i<num_slide;i++)
                {
                    tree_aggregation.add(i, 0.0);
                }
                

                datastream
                .keyBy(0)
                .countWindow(range,slide).trigger(PurgingTrigger.of(CountTrigger.of(slide)))//.evictor(CountEvictor.of(slide))
                .fold(new Integer (0), new FoldFunction<Tuple2<Integer, Integer>, Integer>() {
                   int f1_value=0;
                   int f2_value=0;
                   int count=0;
                   int round_tmp=0;
                   int round=0;
                   @Override
                   public Integer fold(Integer acc, Tuple2<Integer, Integer> value) throws Exception{
                        count++;
                        round_tmp++;

                        if(count<=f1)
                        {
                            f1_value+=value.f1;
                        }
                        else if (count <= f2+f1)
                        {
                            f2_value+=value.f1;
                        }

                        if(round_tmp>=slide)
                        {
                            double forward_aggregate = tree_aggregation.get(round)+f1_value;
                            if(round<=num_slide-2)
                            {
                                //Get the result by combining the pair forward-aggregating node and backward-aggregating node                            
                                tree_aggregation.set(round, forward_aggregate);
                                tree_aggregation.set(round+1, f1_value+tree_aggregation.get(round+1));
                            }
                            else
                            {
                                tree_aggregation.set(round, forward_aggregate);
                                //compute all backward-aggregating nodes when right-most node is visited
                                for(int k=num_slide-2;k>0;k--)
                                {
                                    tree_aggregation.set(k, tree_aggregation.get(k+1)+tree_aggregation.get(k));
                                }
                                tree_aggregation.set(0, 0.0);
                            }
                            round++;
                            if(round==num_slide)
                               round=0;
                            double results=0.0;
                            double forward_aggregate2 = tree_aggregation.get(round)+f2_value;
                            
                            if(round<=num_slide-2)
                            {
                                //Get the result by combining the pair forward-aggregating node and backward-aggregating node                            
                                results = forward_aggregate2 + tree_aggregation.get(round+1);
                                tree_aggregation.set(round, (double)f2_value);
                                tree_aggregation.set(round+1, forward_aggregate2);
                            }
                            else
                            {
                                results = forward_aggregate2;
                                tree_aggregation.set(round, (double)f2_value);
                            }
                            count=0;
                            f1_value=0;
                            f2_value=0;
                            round_tmp=0;
                        acc = (int)results;
                        }
                        return acc;
                   }
                });//.print();//.writeAsText("/Users/bousavong/Desktop/test/text/DEB12/bidirection.txt");//.print();
                }
        env.execute("Word Count Example");
        tEnd = System.currentTimeMillis();
        elapsedSeconds = (tEnd - tStart) / 1000.0;
        double taskCpuTimeNano    = (getCpuTime( ) - startCpuTimeNano) / 1000000000.0;
        double taskUserTimeNano    = (getUserTime( ) - startUserTimeNano) / 1000000000.0;
        double taskSystemTimeNano  = (getSystemTime( ) - startSystemTimeNano) / 1000000000.0;
        System.out.println("taskCpuTimeNano:"+taskCpuTimeNano);
        System.out.println("taskUserTimeNano:"+taskUserTimeNano);
        System.out.println("taskSystemTimeNano:"+taskSystemTimeNano);
        System.out.println("Time:"+elapsedSeconds);
        System.out.println("Finish");
    }
    public static class LineSplitter implements FlatMapFunction<String, Tuple11<Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer>> {
        @Override
        public void flatMap(String line, Collector<Tuple11<Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer>> out) {
            String[] cells = line.split("\\s+");
            out.collect(new Tuple11<>(1, Integer.parseInt(cells[1]), Integer.parseInt(cells[2]), Integer.parseInt(cells[3]), Integer.parseInt(cells[4]), Integer.parseInt(cells[5]), Integer.parseInt(cells[6]), Integer.parseInt(cells[7]), Integer.parseInt(cells[8]), Integer.parseInt(cells[9]), Integer.parseInt(cells[10])));
        }
    }

    public static class LineSplitter2 implements FlatMapFunction<String, Tuple2<Integer, Integer>> {
        @Override
        public void flatMap(String line, Collector<Tuple2<Integer, Integer>> out) {
            String[] cells = line.split("\\s+");
            //out.collect(new Tuple2<>(Integer.parseInt(cells[1]), Integer.parseInt(cells[2])));
            out.collect(new Tuple2<>(1, Integer.parseInt(cells[2])));
        }
    }
    
     // Get CPU time in nanoseconds. 
public static long getCpuTime( ) {
    ThreadMXBean bean = ManagementFactory.getThreadMXBean( );
    return bean.isCurrentThreadCpuTimeSupported( ) ?
        bean.getCurrentThreadCpuTime( ) : 0L;
}
 
// Get user time in nanoseconds. 
public static long getUserTime( ) {
    ThreadMXBean bean = ManagementFactory.getThreadMXBean( );
    return bean.isCurrentThreadCpuTimeSupported( ) ?
        bean.getCurrentThreadUserTime( ) : 0L;
}

// Get system time in nanoseconds. 
public static long getSystemTime( ) {
    ThreadMXBean bean = ManagementFactory.getThreadMXBean( );
    return bean.isCurrentThreadCpuTimeSupported( ) ?
        (bean.getCurrentThreadCpuTime( ) - bean.getCurrentThreadUserTime( )) : 0L;
}
}
//(2nd Optimal, efficient)Bidirection-Tree Approach ========================End 201796=============================
//(2nd Optimal, efficient)Bidirection-Tree Approach ========================End 201796=============================
//(2nd Optimal, efficient)Bidirection-Tree Approach ========================End 201796=============================
//(2nd Optimal, efficient)Bidirection-Tree Approach ========================End 201796=============================
//(2nd Optimal, efficient)Bidirection-Tree Approach ========================End 201796=============================
//(2nd Optimal, efficient)Bidirection-Tree Approach ========================End 201796=============================
*/



















/*
//2-BiX Approach ========================Begin 201796===========================
//2-BiX Approach ========================Begin 201796===========================
//2-BiX Approach ========================Begin 201796===========================
//2-BiX Approach ========================Begin 201796===========================
//2-BiX Approach ========================Begin 201796===========================
//2-BiX Approach ========================Begin 201796===========================
public class Sum {
    public static void main(String[] args) throws Exception{
        // TODO code application logic here
        final StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        //env.setStreamTimeCharacteristic(TimeCharacteristic.ProcessingTime);
        //env.setParallelism(1);
        DataStream<Tuple2<Integer,Integer>> datastream = env.readTextFile("/home/savong/デスクトップ/DEBS2012_Dataset/DEBS2012_129millions.txt")//DEB12/DEBS2012-ChallengeData.txt") //5000000.txt //50000.txt
        .flatMap(new LineSplitter2());
        
        long startCpuTimeNano = getCpuTime( );
        long startSystemTimeNano = getSystemTime( );
        long startUserTimeNano   = getUserTime( );
        long tStart= System.currentTimeMillis();//=0;// = System.currentTimeMillis();
        long tEnd=0;
        double elapsedSeconds=0.0;

        

        int range = 1000000;
                int slide = 1;
                int f2 = range%slide;
                int f1 = slide - f2;
                if(f2==0)
                {
                int num_slide = range/slide;
                
                ArrayList<Node> Tree = new ArrayList<>();
                Node tmp = new Node();
                for(int i=0;i<num_slide;i++)
                {
                    Tree.add(i, tmp);
                }


                datastream
                .keyBy(0)
                .countWindow(range,slide).trigger(PurgingTrigger.of(CountTrigger.of(slide)))//.evictor(CountEvictor.of(slide))
                .fold(new Integer (0), new FoldFunction<Tuple2<Integer, Integer>, Integer>() {
                   int f1_value=0;
                   int count=0;
                   int round_tmp=0;
                   int round=0;
                   @Override
                   public Integer fold(Integer acc, Tuple2<Integer, Integer> value) throws Exception{
                        count++;
                        round_tmp++;

                        if(count<=f1)
                        {
                            f1_value+=value.f1;
                        }

                        //if(round_tmp%slide==0)
                        if(round_tmp>=slide)
                        {
                            Node tmp_agg=new Node();
                            tmp_agg.backward_aggregating=f1_value;
                            if(round-1>=0)
                            {
                                tmp_agg.forward_aggregating = Tree.get(round-1).forward_aggregating+tmp_agg.backward_aggregating;
                            }
                            else
                            {
                                tmp_agg.forward_aggregating = tmp_agg.backward_aggregating;
                            }
                            Tree.set(round, tmp_agg);
                            //Get the result by combining the pair forward-aggregating node and backward-aggregating node                            
                            double results=0.0;
                            if(round<=num_slide-2)
                            {
                                results = tmp_agg.forward_aggregating + Tree.get(round+1).backward_aggregating;
                            }
                            else
                            {
                                results = tmp_agg.forward_aggregating; 
                                //compute all backward-aggregating nodes when right-most node is visited
                                for(int k=num_slide-2;k>0;k--)
                                {
                                    Tree.get(k).backward_aggregating = Tree.get(k).backward_aggregating+Tree.get(k+1).backward_aggregating;
                                }
                            }
                            count=0;
                            f1_value=0;
                            round++;
                            round_tmp=0;
                            if(round==num_slide)
                               round=0;

                        //Integer result=0;//(int)Tree.aggregating;
                        acc = (int)results;
                        }
                        return acc;
                   }
                });//.print();//.writeAsText("/Users/bousavong/Desktop/test/text/DEB12/bidirection.txt");//.print();
                }
                else
                {
                int num_slide = range/slide+1;
                ArrayList<Node> Tree = new ArrayList<>();
                for(int i=0;i<num_slide;i++)
                {
                    Node tmp = new Node();
                    Tree.add(i, tmp);
                }
                

                datastream
                .keyBy(0)
                .countWindow(range,slide).trigger(PurgingTrigger.of(CountTrigger.of(slide)))//.evictor(CountEvictor.of(slide))
                .fold(new Integer (0), new FoldFunction<Tuple2<Integer, Integer>, Integer>() {
                   int f1_value=0;
                   int f2_value=0;
                   int count=0;
                   int round_tmp=0;
                   int round=0;
                   @Override
                   public Integer fold(Integer acc, Tuple2<Integer, Integer> value) throws Exception{
                        count++;
                        round_tmp++;

                        if(count<=f1)
                        {
                            f1_value+=value.f1;
                        }
                        else if (count <= f2+f1)
                        {
                            f2_value+=value.f1;
                        }

                        if(round_tmp>=slide)
                        {
                            Node tmp_agg=new Node();
                            tmp_agg.backward_aggregating=f1_value+Tree.get(round).backward_aggregating;
                            if(round<1)
                            {
                                tmp_agg.forward_aggregating = tmp_agg.backward_aggregating;
                                Tree.set(round, tmp_agg);
                            }
                            else
                            {
                                tmp_agg.forward_aggregating = Tree.get(round-1).forward_aggregating+tmp_agg.backward_aggregating;
                                Tree.set(round, tmp_agg);
                            }
                            
                            //compute all backward-aggregating nodes when right-most node is visited                                
                            if(round==num_slide-1)
                            {
                                for(int k=num_slide-2;k>0;k--)
                                {
                                    Tree.get(k).backward_aggregating = Tree.get(k).backward_aggregating+Tree.get(k+1).backward_aggregating;
                                }
                            }
                            round++;
                            Node tmp_agg2=new Node();
                            tmp_agg2.backward_aggregating=f2_value;
                            if(round>=num_slide)
                            {
                                round=0;
                                tmp_agg2.forward_aggregating = tmp_agg2.backward_aggregating;
                                Tree.set(0, tmp_agg2);  
                            }
                            else
                            {
                                tmp_agg2.forward_aggregating = Tree.get(round-1).forward_aggregating+tmp_agg2.backward_aggregating;
                                Tree.set(round, tmp_agg2);  
                            }
                            
                            //Get the result by combining the pair forward-aggregating node and backward-aggregating node                                                        
                            double results=0.0;
                            if(round==num_slide-1)
                            {
                                results = Tree.get(round).forward_aggregating;
                            }
                            else
                            {
                                results = Tree.get(round).forward_aggregating+Tree.get(round+1).backward_aggregating;
                            }


                            count=0;
                            f1_value=0;
                            f2_value=0;
//                            round++;
                            round_tmp=0;
                            if(round==num_slide)
                               round=0;
                        acc = (int)results;
                        }
                        return acc;
                   }
                });//.print();//.writeAsText("/Users/bousavong/Desktop/test/text/DEB12/bidirection.txt");//.print();
                }

        env.execute("Word Count Example");
        tEnd = System.currentTimeMillis();
        elapsedSeconds = (tEnd - tStart) / 1000.0;
        double taskCpuTimeNano    = (getCpuTime( ) - startCpuTimeNano) / 1000000000.0;
        double taskUserTimeNano    = (getUserTime( ) - startUserTimeNano) / 1000000000.0;
        double taskSystemTimeNano  = (getSystemTime( ) - startSystemTimeNano) / 1000000000.0;
        System.out.println("taskCpuTimeNano:"+taskCpuTimeNano);
        System.out.println("taskUserTimeNano:"+taskUserTimeNano);
        System.out.println("taskSystemTimeNano:"+taskSystemTimeNano);
        System.out.println("Time:"+elapsedSeconds);
        System.out.println("Finish");
    }
    public static class LineSplitter implements FlatMapFunction<String, Tuple11<Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer>> {
        @Override
        public void flatMap(String line, Collector<Tuple11<Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer>> out) {
            String[] cells = line.split("\\s+");
            out.collect(new Tuple11<>(1, Integer.parseInt(cells[1]), Integer.parseInt(cells[2]), Integer.parseInt(cells[3]), Integer.parseInt(cells[4]), Integer.parseInt(cells[5]), Integer.parseInt(cells[6]), Integer.parseInt(cells[7]), Integer.parseInt(cells[8]), Integer.parseInt(cells[9]), Integer.parseInt(cells[10])));
        }
    }

    public static class LineSplitter2 implements FlatMapFunction<String, Tuple2<Integer, Integer>> {
        @Override
        public void flatMap(String line, Collector<Tuple2<Integer, Integer>> out) {
            String[] cells = line.split("\\s+");
            //out.collect(new Tuple2<>(Integer.parseInt(cells[1]), Integer.parseInt(cells[2])));
            out.collect(new Tuple2<>(1, Integer.parseInt(cells[2])));
        }
    }
    public static class Node implements Serializable
    {
        double forward_aggregating;
        double backward_aggregating;
    }
    
            // Get CPU time in nanoseconds. 
public static long getCpuTime( ) {
    ThreadMXBean bean = ManagementFactory.getThreadMXBean( );
    return bean.isCurrentThreadCpuTimeSupported( ) ?
        bean.getCurrentThreadCpuTime( ) : 0L;
}
 
// Get user time in nanoseconds. 
public static long getUserTime( ) {
    ThreadMXBean bean = ManagementFactory.getThreadMXBean( );
    return bean.isCurrentThreadCpuTimeSupported( ) ?
        bean.getCurrentThreadUserTime( ) : 0L;
}

// Get system time in nanoseconds. 
public static long getSystemTime( ) {
    ThreadMXBean bean = ManagementFactory.getThreadMXBean( );
    return bean.isCurrentThreadCpuTimeSupported( ) ?
        (bean.getCurrentThreadCpuTime( ) - bean.getCurrentThreadUserTime( )) : 0L;
}
}
//2-BiX Approach ========================End 201796=============================
//2-BiX Approach ========================End 201796=============================
//2-BiX Approach ========================End 201796=============================
//2-BiX Approach ========================End 201796=============================
//2-BiX Approach ========================End 201796=============================
//2-BiX Approach ========================End 201796=============================
*/














/*
//3-BiX Approach ========================Begin 201796===========================
//3-BiX Approach ========================Begin 201796===========================
//3-BiX Approach ========================Begin 201796===========================
//3-BiX Approach ========================Begin 201796===========================
//3-BiX Approach ========================Begin 201796===========================
//3-BiX Approach ========================Begin 201796===========================
public class Sum {
    public static void main(String[] args) throws Exception{
        // TODO code application logic here
        final StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        //env.setStreamTimeCharacteristic(TimeCharacteristic.ProcessingTime);
        //env.setParallelism(1);
        DataStream<Tuple2<Integer,Integer>> datastream = env.readTextFile("/home/savong/デスクトップ/DEBS2012_Dataset/DEBS2012_129millions.txt")//DEB12/DEBS2012-ChallengeData.txt") //5000000.txt //50000.txt
        .flatMap(new LineSplitter2());
        
                long startCpuTimeNano = getCpuTime( );
        long startSystemTimeNano = getSystemTime( );
        long startUserTimeNano   = getUserTime( );
        long tStart= System.currentTimeMillis();//=0;// = System.currentTimeMillis();
        long tEnd=0;
        double elapsedSeconds=0.0;
        

        int range = 100000000;
                int slide = 1;
                int f2 = range%slide;
                int f1 = slide - f2;
                if(f2==0)
                {
                int num_slide = range/slide;
                
                ArrayList<Node> Tree = new ArrayList<>();
                Node tmp = new Node();
                for(int i=0;i<num_slide;i++)
                {
                    Tree.add(i, tmp);
                }

                datastream
                .keyBy(0)
                .countWindow(range,slide).trigger(PurgingTrigger.of(CountTrigger.of(slide)))//.evictor(CountEvictor.of(slide))
                .fold(new Integer (0), new FoldFunction<Tuple2<Integer, Integer>, Integer>() {
                   int f1_value=0;
                   int count=0;
                   int round_tmp=0;
                   int round=0;
                   @Override
                   public Integer fold(Integer acc, Tuple2<Integer, Integer> value) throws Exception{
                        count++;
                        round_tmp++;

                        if(count<=f1)
                        {
                            f1_value+=value.f1;
                        }

                        //if(round_tmp%slide==0)
                        if(round_tmp>=slide)
                        {
                            Node tmp_agg=new Node();
                            tmp_agg.leaf_aggregating=f1_value;
                            if(round-1>=0)
                            {
                                tmp_agg.forward_aggregating = Tree.get(round-1).forward_aggregating+tmp_agg.leaf_aggregating;
                            }
                            else
                            {
                                tmp_agg.forward_aggregating = tmp_agg.leaf_aggregating;
                            }
                            Tree.set(round, tmp_agg);
                            //Get the result by combining the pair forward-aggregating node and backward-aggregating node                            
                            double results=0.0;
                            if(round<=num_slide-2)
                            {
                                results = tmp_agg.forward_aggregating + Tree.get(round+1).backward_aggregating;
                            }
                            else
                            {
                                results = tmp_agg.forward_aggregating; 
                                //compute all backward-aggregating nodes when right-most node is visited
                                if(round==num_slide-1)
                                {
                                    for(int k=num_slide-1;k>0;k--)
                                    {
                                        if(k==num_slide-1)
                                        {
                                            Tree.get(k).backward_aggregating = Tree.get(k).leaf_aggregating;
                                        }
                                        else
                                        {
                                            Tree.get(k).backward_aggregating = Tree.get(k).leaf_aggregating+Tree.get(k+1).backward_aggregating;
                                        }

                                    }
                                }
                            }
                            count=0;
                            f1_value=0;
                            round++;
                            round_tmp=0;
                            if(round==num_slide)
                               round=0;

                        //Integer result=0;//(int)Tree.aggregating;
                        acc = (int)results;
                        }
                        return acc;
                   }
                });//.print();
                }
                else
                {
                int num_slide = range/slide+1;
                ArrayList<Node> Tree = new ArrayList<>();
                for(int i=0;i<num_slide;i++)
                {
                    Node tmp = new Node();
                    Tree.add(i, tmp);
                }
                datastream
                .keyBy(0)
                .countWindow(range,slide).trigger(PurgingTrigger.of(CountTrigger.of(slide)))//.evictor(CountEvictor.of(slide))
                .fold(new Integer (0), new FoldFunction<Tuple2<Integer, Integer>, Integer>() {
                   int f1_value=0;
                   int f2_value=0;
                   int count=0;
                   int round_tmp=0;
                   int round=0;
                   @Override
                   public Integer fold(Integer acc, Tuple2<Integer, Integer> value) throws Exception{
                        count++;
                        round_tmp++;

                        if(count<=f1)
                        {
                            f1_value+=value.f1;
                        }
                        else if (count <= f2+f1)
                        {
                            f2_value+=value.f1;
                        }

                        if(round_tmp>=slide)
                        {
                            Node tmp_agg=new Node();
                            tmp_agg.leaf_aggregating=f1_value+Tree.get(round).leaf_aggregating;
                            if(round<1)
                            {
                                tmp_agg.forward_aggregating = tmp_agg.leaf_aggregating;
                                Tree.set(round, tmp_agg);
                            }
                            else
                            {
                                tmp_agg.forward_aggregating = Tree.get(round-1).forward_aggregating+tmp_agg.leaf_aggregating;
                                Tree.set(round, tmp_agg);
                            }
                            
                            //compute all backward-aggregating nodes when right-most node is visited                                
                            if(round==num_slide-1)
                            {
                                for(int k=num_slide-1;k>0;k--)
                                {
                                    if(k==num_slide-1)
                                    {
                                        Tree.get(k).backward_aggregating = Tree.get(k).leaf_aggregating;
                                    }
                                    else
                                    {
                                        Tree.get(k).backward_aggregating = Tree.get(k).leaf_aggregating+Tree.get(k+1).backward_aggregating;
                                    }

                                }
                            }
                            round++;
                            Node tmp_agg2=new Node();
                            tmp_agg2.leaf_aggregating=f2_value;
                            if(round>=num_slide)
                            {
                                round=0;
                                tmp_agg2.forward_aggregating = tmp_agg2.leaf_aggregating;
                                Tree.set(0, tmp_agg2);  
                            }
                            else
                            {
                                tmp_agg2.forward_aggregating = Tree.get(round-1).forward_aggregating+tmp_agg2.leaf_aggregating;
                                Tree.set(round, tmp_agg2);  
                            }
                            
                            //Get the result by combining the pair forward-aggregating node and backward-aggregating node                                                        
                            double results=0.0;
                            if(round==num_slide-1)
                            {
                                results = Tree.get(round).forward_aggregating;
                            }
                            else
                            {
                                results = Tree.get(round).forward_aggregating+Tree.get(round+1).backward_aggregating;
                            }


                            count=0;
                            f1_value=0;
                            f2_value=0;
//                            round++;
                            round_tmp=0;
                            if(round==num_slide)
                               round=0;
                        acc = (int)results;
                        }
                        return acc;
                   }
                });//.print();
                }

        env.execute("Word Count Example");
        tEnd = System.currentTimeMillis();
        elapsedSeconds = (tEnd - tStart) / 1000.0;
        double taskCpuTimeNano    = (getCpuTime( ) - startCpuTimeNano) / 1000000000.0;
        double taskUserTimeNano    = (getUserTime( ) - startUserTimeNano) / 1000000000.0;
        double taskSystemTimeNano  = (getSystemTime( ) - startSystemTimeNano) / 1000000000.0;
        System.out.println("taskCpuTimeNano:"+taskCpuTimeNano);
        System.out.println("taskUserTimeNano:"+taskUserTimeNano);
        System.out.println("taskSystemTimeNano:"+taskSystemTimeNano);
        System.out.println("Time:"+elapsedSeconds);
        System.out.println("Finish");
    }
    public static class LineSplitter implements FlatMapFunction<String, Tuple11<Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer>> {
        @Override
        public void flatMap(String line, Collector<Tuple11<Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer>> out) {
            String[] cells = line.split("\\s+");
            out.collect(new Tuple11<>(1, Integer.parseInt(cells[1]), Integer.parseInt(cells[2]), Integer.parseInt(cells[3]), Integer.parseInt(cells[4]), Integer.parseInt(cells[5]), Integer.parseInt(cells[6]), Integer.parseInt(cells[7]), Integer.parseInt(cells[8]), Integer.parseInt(cells[9]), Integer.parseInt(cells[10])));
        }
    }

    public static class LineSplitter2 implements FlatMapFunction<String, Tuple2<Integer, Integer>> {
        @Override
        public void flatMap(String line, Collector<Tuple2<Integer, Integer>> out) {
            String[] cells = line.split("\\s+");
            //out.collect(new Tuple2<>(Integer.parseInt(cells[1]), Integer.parseInt(cells[2])));
            out.collect(new Tuple2<>(1, Integer.parseInt(cells[2])));
        }
    }
    public static class Node implements Serializable
    {
        double leaf_aggregating; // maintain the lowest aggregate at the leaf node
        double forward_aggregating;
        double backward_aggregating;
    }
    
            // Get CPU time in nanoseconds. 
public static long getCpuTime( ) {
    ThreadMXBean bean = ManagementFactory.getThreadMXBean( );
    return bean.isCurrentThreadCpuTimeSupported( ) ?
        bean.getCurrentThreadCpuTime( ) : 0L;
}
 
// Get user time in nanoseconds. 
public static long getUserTime( ) {
    ThreadMXBean bean = ManagementFactory.getThreadMXBean( );
    return bean.isCurrentThreadCpuTimeSupported( ) ?
        bean.getCurrentThreadUserTime( ) : 0L;
}

// Get system time in nanoseconds. 
public static long getSystemTime( ) {
    ThreadMXBean bean = ManagementFactory.getThreadMXBean( );
    return bean.isCurrentThreadCpuTimeSupported( ) ?
        (bean.getCurrentThreadCpuTime( ) - bean.getCurrentThreadUserTime( )) : 0L;
}
}
//3-BiX Approach ========================End 201796=============================
//3-BiX Approach ========================End 201796=============================
//3-BiX Approach ========================End 201796=============================
//3-BiX Approach ========================End 201796=============================
//3-BiX Approach ========================End 201796=============================
//3-BiX Approach ========================End 201796=============================
*/













/*
//FlatFIT Approach ========================Begin 201796===========================
//FlatFIT Approach ========================Begin 201796===========================
//FlatFIT Approach ========================Begin 201796===========================
//FlatFIT Approach ========================Begin 201796===========================
//FlatFIT Approach ========================Begin 201796===========================
//FlatFIT Approach ========================Begin 201796===========================                
public class Sum {
    public static void main(String[] args) throws Exception{

        // TODO code application logic here
        final StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        //env.setStreamTimeCharacteristic(TimeCharacteristic.ProcessingTime);
        //env.setParallelism(1);
        DataStream<Tuple2<Integer,Integer>> datastream = env.readTextFile("/home/savong/デスクトップ/DEBS2012_Dataset/DEBS2012_129millions.txt")//DEB12/DEBS2012-ChallengeData.txt") //5000000.txt //50000.txt
        .flatMap(new LineSplitter2());
        
                long startCpuTimeNano = getCpuTime( );
        long startSystemTimeNano = getSystemTime( );
        long startUserTimeNano   = getUserTime( );
        long tStart= System.currentTimeMillis();//=0;// = System.currentTimeMillis();
        long tEnd=0;
        double elapsedSeconds=0.0;

        
        int range = 1000;
        int slide = 1;
        int f2 = range%slide;
        int f1 = slide - f2;
        if(f2==0)
        {
            int num_slide = range/slide;
            double parent_forward_aggregate=0.0;
            double results = 0.0;
            ArrayList<Double> Partials = new ArrayList<>();
            ArrayList<Integer> Pointers = new ArrayList<>();
            Stack Positions = new Stack();
            for(int i=0;i<num_slide;i++)
            {
                Partials.add(i, 0.0);
                Pointers.add(i, i+1);
            }
            Pointers.set(num_slide-1, 0);
            //int currInd=0;
            //int prevInd=range-1;
            datastream
            .keyBy(0)
            .countWindow(range,slide).trigger(PurgingTrigger.of(CountTrigger.of(slide)))//.evictor(CountEvictor.of(slide))
            .fold(new Integer (0), new FoldFunction<Tuple2<Integer, Integer>, Integer>() {
               double f1_value=0;
               double f2_value=0;
               int count=0;
               int round_tmp=0;
               int round=0;
               int currInd=0;
               int prevInd=num_slide-1;

               @Override
               public Integer fold(Integer acc, Tuple2<Integer, Integer> value) throws Exception{
                    count++;
                    round_tmp++;

                    if(count<=f1)
                    {
                        f1_value+=value.f1;
                    }

                    //if(round_tmp%slide==0)
                    if(round_tmp>=slide)
                    {
                        round_tmp=0;
                        round++;
                        Partials.set(prevInd, f1_value);
                        Pointers.set(prevInd, currInd);
                        int startInd=currInd-num_slide;
                        if(startInd<0)
                        {
                            startInd+=num_slide;
                        }
                        do
                        {
                            Positions.push(startInd);
                            startInd=Pointers.get(startInd);
                        }while(startInd != currInd);
                        int p_k=0;
                        if(Positions.size()>1)
                            p_k = (int)Positions.pop();
                        double answer=Partials.get(p_k);
                        int tempInd=0;
                        while(Positions.size()>1)
                        {
                            tempInd = (int)Positions.pop();
                            answer+=Partials.get(tempInd);
                            Partials.set(tempInd, answer);
                            Pointers.set(tempInd, currInd);
                        }
                        if(Positions.size()>1)
                        tempInd = (int)Positions.pop();
                        answer+=Partials.get(tempInd);
                        prevInd = currInd;
                        currInd++;
                        if(currInd == num_slide)
                            currInd=0;
                        count=0;
                        f1_value=0;
                        acc = (int)answer;
                    }
                    return acc;
               }
            });//.print();//.writeAsText("/Users/bousavong/Desktop/test/text/DEB12/flatfit.txt");//.print();
        }
        else
        {

        }

        env.execute("Word Count Example");
        tEnd = System.currentTimeMillis();
        elapsedSeconds = (tEnd - tStart) / 1000.0;
        double taskCpuTimeNano    = (getCpuTime( ) - startCpuTimeNano) / 1000000000.0;
        double taskUserTimeNano    = (getUserTime( ) - startUserTimeNano) / 1000000000.0;
        double taskSystemTimeNano  = (getSystemTime( ) - startSystemTimeNano) / 1000000000.0;
        System.out.println("taskCpuTimeNano:"+taskCpuTimeNano);
        System.out.println("taskUserTimeNano:"+taskUserTimeNano);
        System.out.println("taskSystemTimeNano:"+taskSystemTimeNano);
        System.out.println("Time:"+elapsedSeconds);
        System.out.println("Finish");
    }
    public static class LineSplitter implements FlatMapFunction<String, Tuple11<Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer>> {
        @Override
        public void flatMap(String line, Collector<Tuple11<Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer>> out) {
            String[] cells = line.split("\\s+");
            out.collect(new Tuple11<>(1, Integer.parseInt(cells[1]), Integer.parseInt(cells[2]), Integer.parseInt(cells[3]), Integer.parseInt(cells[4]), Integer.parseInt(cells[5]), Integer.parseInt(cells[6]), Integer.parseInt(cells[7]), Integer.parseInt(cells[8]), Integer.parseInt(cells[9]), Integer.parseInt(cells[10])));
        }
    }

    public static class LineSplitter2 implements FlatMapFunction<String, Tuple2<Integer, Integer>> {
        @Override
        public void flatMap(String line, Collector<Tuple2<Integer, Integer>> out) {
            String[] cells = line.split("\\s+");
            //out.collect(new Tuple2<>(Integer.parseInt(cells[1]), Integer.parseInt(cells[2])));
            out.collect(new Tuple2<>(1, Integer.parseInt(cells[2])));
        }
    }
           // Get CPU time in nanoseconds. 
public static long getCpuTime( ) {
    ThreadMXBean bean = ManagementFactory.getThreadMXBean( );
    return bean.isCurrentThreadCpuTimeSupported( ) ?
        bean.getCurrentThreadCpuTime( ) : 0L;
}
 
// Get user time in nanoseconds. 
public static long getUserTime( ) {
    ThreadMXBean bean = ManagementFactory.getThreadMXBean( );
    return bean.isCurrentThreadCpuTimeSupported( ) ?
        bean.getCurrentThreadUserTime( ) : 0L;
}

// Get system time in nanoseconds. 
public static long getSystemTime( ) {
    ThreadMXBean bean = ManagementFactory.getThreadMXBean( );
    return bean.isCurrentThreadCpuTimeSupported( ) ?
        (bean.getCurrentThreadCpuTime( ) - bean.getCurrentThreadUserTime( )) : 0L;
}
}
//FlatFIT Approach ========================End 201796=============================
//FlatFIT Approach ========================End 201796=============================
//FlatFIT Approach ========================End 201796=============================
//FlatFIT Approach ========================End 201796=============================
//FlatFIT Approach ========================End 201796=============================
//FlatFIT Approach ========================End 201796=============================
*/








/*
//tmp_FlatFIT Approach ========================Begin 201796===========================
//tmp_FlatFIT Approach ========================Begin 201796===========================
//tmp_FlatFIT Approach ========================Begin 201796===========================
//tmp_FlatFIT Approach ========================Begin 201796===========================
//tmp_FlatFIT Approach ========================Begin 201796===========================
//tmp_FlatFIT Approach ========================Begin 201796===========================                
public class Sum {
    public static void main(String[] args) throws Exception{
                // TODO code application logic here
        final StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        //env.setStreamTimeCharacteristic(TimeCharacteristic.ProcessingTime);
        //env.setParallelism(1);
        DataStream<Tuple2<Integer,Integer>> datastream = env.readTextFile("/home/savong/デスクトップ/DEBS2012_Dataset/DEBS2012_129millions.txt")//DEB12/DEBS2012-ChallengeData.txt") //5000000.txt //50000.txt
        .flatMap(new LineSplitter2());
        
        
                long startCpuTimeNano = getCpuTime( );
        long startSystemTimeNano = getSystemTime( );
        long startUserTimeNano   = getUserTime( );
        long tStart= System.currentTimeMillis();//=0;// = System.currentTimeMillis();
        long tEnd=0;
        Double elapsedSeconds=0.0;


        
        int range = 10000000;
        int slide = 1;
        int f2 = range%slide;
        int f1 = slide - f2;
        if(f2==0)
        {
            int num_slide = range/slide;
            double parent_forward_aggregate=0.0;
            double results = 0.0;
                       

            HashMap<Integer, Double> Partials = new HashMap<>();
            HashMap<Integer, Integer> Pointers = new HashMap<>();
            Stack Positions = new Stack();
            for(int i=0;i<num_slide;i++)
            {
                Partials.put(i, 0.0);
                Pointers.put(i, i+1);
            }
            Pointers.put(num_slide-1, 0);
            datastream
            .keyBy(0)
            .countWindow(range,slide).trigger(PurgingTrigger.of(CountTrigger.of(slide)))//.evictor(CountEvictor.of(slide))
            .fold(new Integer (0), new FoldFunction<Tuple2<Integer, Integer>, Integer>() {
               double f1_value=0;
               double f2_value=0;
               int count=0;
               int round_tmp=0;
               int round=0;
               int currInd=0;
               int prevInd=num_slide-1;

               @Override
               public Integer fold(Integer acc, Tuple2<Integer, Integer> value) throws Exception{
                    count++;
                    round_tmp++;

                    if(count<=f1)
                    {
                        f1_value+=value.f1;
                    }

                    //if(round_tmp%slide==0)
                    if(round_tmp>=slide)
                    {
                        round_tmp=0;
                        round++;
                        Partials.put(prevInd, f1_value);
                        Pointers.put(prevInd, currInd);
                        int startInd=currInd-num_slide;
                        if(startInd<0)
                        {
                            startInd+=num_slide;
                        }
                        do
                        {
                            Positions.push(startInd);
                            if(Pointers.containsKey(startInd))
                                startInd=Pointers.get(startInd);
                        }while(startInd != currInd);
                        double answer=0.0;
                        int p_k = 0;
                        if(Positions.size()>1)
                            p_k = (int)Positions.pop();
                        if(Partials.containsKey(p_k))
                            answer=Partials.get(p_k);
                        int tempInd=0;
                        while(Positions.size()>1)
                        {
                            tempInd = (int)Positions.pop();
                            if(Partials.containsKey(tempInd))
                                answer+=Partials.get(tempInd);
                            Partials.put(tempInd, answer);
                            Pointers.put(tempInd, currInd);
                        }
                        if(Positions.size()>1)
                        tempInd = (int)Positions.pop();
                        if(Partials.containsKey(tempInd))
                            answer+=Partials.get(tempInd);
                        prevInd = currInd;
                        currInd++;
                        if(currInd == num_slide)
                            currInd=0;
                        count=0;
                        f1_value=0;
                        acc = (int)answer;
                    }
                    return acc;
               }
            });//.print();//.writeAsText("/Users/bousavong/Desktop/test/text/DEB12/flatfit.txt");//.print();
        }
        else
        {

        }

        env.execute("Word Count Example");
        tEnd = System.currentTimeMillis();
        elapsedSeconds = (tEnd - tStart) / 1000.0;
        double taskCpuTimeNano    = (getCpuTime( ) - startCpuTimeNano) / 1000000000.0;
        double taskUserTimeNano    = (getUserTime( ) - startUserTimeNano) / 1000000000.0;
        double taskSystemTimeNano  = (getSystemTime( ) - startSystemTimeNano) / 1000000000.0;
        System.out.println("taskCpuTimeNano:"+taskCpuTimeNano);
        System.out.println("taskUserTimeNano:"+taskUserTimeNano);
        System.out.println("taskSystemTimeNano:"+taskSystemTimeNano);
        System.out.println("Time:"+elapsedSeconds);
        System.out.println("Finish");
    }
    public static class LineSplitter implements FlatMapFunction<String, Tuple11<Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer>> {
        @Override
        public void flatMap(String line, Collector<Tuple11<Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer>> out) {
            String[] cells = line.split("\\s+");
            out.collect(new Tuple11<>(1, Integer.parseInt(cells[1]), Integer.parseInt(cells[2]), Integer.parseInt(cells[3]), Integer.parseInt(cells[4]), Integer.parseInt(cells[5]), Integer.parseInt(cells[6]), Integer.parseInt(cells[7]), Integer.parseInt(cells[8]), Integer.parseInt(cells[9]), Integer.parseInt(cells[10])));
        }
    }

    public static class LineSplitter2 implements FlatMapFunction<String, Tuple2<Integer, Integer>> {
        @Override
        public void flatMap(String line, Collector<Tuple2<Integer, Integer>> out) {
            String[] cells = line.split("\\s+");
            //out.collect(new Tuple2<>(Integer.parseInt(cells[1]), Integer.parseInt(cells[2])));
            out.collect(new Tuple2<>(1, Integer.parseInt(cells[2])));
        }
    }
    
           // Get CPU time in nanoseconds. 
public static long getCpuTime( ) {
    ThreadMXBean bean = ManagementFactory.getThreadMXBean( );
    return bean.isCurrentThreadCpuTimeSupported( ) ?
        bean.getCurrentThreadCpuTime( ) : 0L;
}
 
// Get user time in nanoseconds. 
public static long getUserTime( ) {
    ThreadMXBean bean = ManagementFactory.getThreadMXBean( );
    return bean.isCurrentThreadCpuTimeSupported( ) ?
        bean.getCurrentThreadUserTime( ) : 0L;
}

// Get system time in nanoseconds. 
public static long getSystemTime( ) {
    ThreadMXBean bean = ManagementFactory.getThreadMXBean( );
    return bean.isCurrentThreadCpuTimeSupported( ) ?
        (bean.getCurrentThreadCpuTime( ) - bean.getCurrentThreadUserTime( )) : 0L;
}
}
//tmp_FlatFIT Approach ========================End 201796=============================
//tmp_FlatFIT Approach ========================End 201796=============================
//tmp_FlatFIT Approach ========================End 201796=============================
//tmp_FlatFIT Approach ========================End 201796=============================
//tmp_FlatFIT Approach ========================End 201796=============================
//tmp_FlatFIT Approach ========================End 201796=============================
*/











/*
//Two_Stacks Approach ========================Begin 2018321===========================
//Two_Stacks Approach ========================Begin 2018321===========================
//Two_Stacks Approach ========================Begin 2018321===========================
//Two_Stacks Approach ========================Begin 2018321===========================
//Two_Stacks Approach ========================Begin 2018321===========================
//Two_Stacks Approach ========================Begin 2018321===========================
public class Sum {
    public static void main(String[] args) throws Exception{
        // TODO code application logic here
        final StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        //env.setStreamTimeCharacteristic(TimeCharacteristic.ProcessingTime);
        //env.setParallelism(1);
        
      
        
        

        DataStream<Tuple2<Integer,Integer>> datastream = env.readTextFile("/home/savong/デスクトップ/DEBS2012_Dataset/DEBS2012_129millions.txt")//DEB12/DEBS2012-ChallengeData.txt") //5000000.txt //50000.txt
        .flatMap(new LineSplitter2());
        
        
long startCpuTimeNano = getCpuTime( );
long startSystemTimeNano = getSystemTime( );
long startUserTimeNano   = getUserTime( );
long tStart= System.currentTimeMillis();//=0;// = System.currentTimeMillis();
long tEnd=0;
Double elapsedSeconds=0.0;

        int range = 100000000;
                int slide = 1;
                int f2 = range%slide;
                int f1 = slide - f2;
                if(f2==0)
                {
                int num_slide = range/slide;              
                Stack<Node> F = new Stack();
                Stack<Node> B = new Stack();

                datastream
                .keyBy(0)
                .countWindow(range,slide).trigger(PurgingTrigger.of(CountTrigger.of(slide)))//.evictor(CountEvictor.of(slide))
                .fold(new Integer (0), new FoldFunction<Tuple2<Integer, Integer>, Integer>() {
                   double f1_value=0;
                   int count=0;
                   int round_tmp=0;
                   int round=0;
                   @Override
                   public Integer fold(Integer acc, Tuple2<Integer, Integer> value) throws Exception{
                       Integer agg =0;
                       for(int k=0;k<100;k++)
                       {
                           agg++;
                           if(agg==5)
                               agg*=2;
                       }
                        count++;
                        round_tmp++;
                        if(count<=f1)
                        {
                            f1_value+=value.f1;
                        }
                        //if(round_tmp%slide==0)
                        if(round_tmp>=slide)
                        {
                            round++;
                            Node element = new Node();
                            element.val = f1_value;
                            if(B.isEmpty())
                                element.agg = f1_value;
                            else
                                element.agg = f1_value+B.peek().agg;
                            //insert
                            B.push(element);
                            //pop
                            if(round >= num_slide)
                            {
                                if(F.isEmpty())
                                {
                                    while(!B.isEmpty())
                                    {
                                        Node element1 = new Node();
                                        element1.val = B.peek().val;
                                        if(F.isEmpty())
                                            element1.agg = B.peek().val;
                                        else
                                            element1.agg = B.peek().val+F.peek().agg;
                                        F.push(element1);
                                        B.pop();
                                    }
                                }
                                round=0;
                            }
                            //result
                            double results=0.0;
                            if(!F.isEmpty())
                                if(!B.isEmpty())
                                    results = B.peek().agg+F.pop().agg;
                                else
                                    results = F.pop().agg;
                            else
                                if(!B.isEmpty())
                                    results = B.peek().agg;

                        count=0;
                        f1_value=0;
                        round_tmp=0;      
                        acc = (int)results;
                        }
                        return acc;
                   }
                });//.print();//.writeAsText("/Users/bousavong/Desktop/test/text/DEB12/bidirection.txt");//.print();
                }
                else
                {
                Stack<Node> F = new Stack();
                Stack<Node> B = new Stack();

                int num_slide = range/slide+1;
                double[] tree_aggregation = new double[num_slide];                 

                datastream
                .keyBy(0)
                .countWindow(range,slide).trigger(PurgingTrigger.of(CountTrigger.of(slide)))//.evictor(CountEvictor.of(slide))
                .fold(new Integer (0), new FoldFunction<Tuple2<Integer, Integer>, Integer>() {
                   double f1_value=0;
                   double f2_value=0;
                   int count=0;
                   int round_tmp=0;
                   int round=0;
                   int window = 0;
                   @Override
                   public Integer fold(Integer acc, Tuple2<Integer, Integer> value) throws Exception{
                        count++;
                        round_tmp++;
                        window++;
                        if(count<=f1)
                        {
                            f1_value+=value.f1;
                        }
                        else if (count <= f2+f1)
                        {
                            f2_value+=value.f1;
                        }

                        //double forward_aggregate = tree_aggregation[round]+f1_value;
                        if(round_tmp>=slide)
                        {
                            Node element = new Node();
                            
                            if(B.isEmpty())
                            {
                                element.val = f1_value;
                                element.agg = f1_value;
                            }
                            else
                            {
                                element.val = f1_value+B.peek().val;
                                element.agg = f1_value+B.pop().agg;
                            }
                            //insert
                            B.push(element);

                            round++;
                            if(round==num_slide)
                               round=0;
                            
                            
                            //pop
                            if(window > range)
                            {
                                if(F.isEmpty())
                                {
                                    while(!B.isEmpty())
                                    {
                                        Node element1 = new Node();
                                        element1.val = B.peek().val;
                                        if(F.isEmpty())
                                            element1.agg = B.peek().val;
                                        else
                                            element1.agg = B.peek().val+F.peek().agg;
                                        F.push(element1);
                                        B.pop();
                                    }
                                }
                                F.pop();
                            }

                            
                            
                            Node element2 = new Node();
                            element2.val = f2_value;
                            if(B.isEmpty())
                                element2.agg = f2_value;
                            else
                                element2.agg = f2_value+B.peek().agg;
                            //insert
                            B.push(element2);
                            
   
                            //result
                            double results=0.0;
                            if(!F.isEmpty())
                                if(!B.isEmpty())
                                    results = B.peek().agg+F.peek().agg;
                                else
                                    results = F.peek().agg;
                            else
                                if(!B.isEmpty())
                                    results = B.peek().agg;
                            
                            count=0;
                            f1_value=0;
                            f2_value=0;
                            round_tmp=0;
                        acc = (int)results;
                        }
                        return acc;
                   }
                });//.print();//.writeAsText("/Users/bousavong/Desktop/test/text/DEB12/bidirection.txt");//.print();
                }
        env.execute("Word Count Example");
        tEnd = System.currentTimeMillis();
        elapsedSeconds = (tEnd - tStart) / 1000.0;
        double taskCpuTimeNano    = (getCpuTime( ) - startCpuTimeNano) / 1000000000.0;
        double taskUserTimeNano    = (getUserTime( ) - startUserTimeNano) / 1000000000.0;
        double taskSystemTimeNano  = (getSystemTime( ) - startSystemTimeNano) / 1000000000.0;
        System.out.println("taskCpuTimeNano:"+taskCpuTimeNano);
        System.out.println("taskUserTimeNano:"+taskUserTimeNano);
        System.out.println("taskSystemTimeNano:"+taskSystemTimeNano);
        System.out.println("Time:"+elapsedSeconds);
        System.out.println("Finish");
    }
    public static class LineSplitter implements FlatMapFunction<String, Tuple11<Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer>> {
        @Override
        public void flatMap(String line, Collector<Tuple11<Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer>> out) {
            String[] cells = line.split("\\s+");
            out.collect(new Tuple11<>(1, Integer.parseInt(cells[1]), Integer.parseInt(cells[2]), Integer.parseInt(cells[3]), Integer.parseInt(cells[4]), Integer.parseInt(cells[5]), Integer.parseInt(cells[6]), Integer.parseInt(cells[7]), Integer.parseInt(cells[8]), Integer.parseInt(cells[9]), Integer.parseInt(cells[10])));
        }
    }

    public static class LineSplitter2 implements FlatMapFunction<String, Tuple2<Integer, Integer>> {
        @Override
        public void flatMap(String line, Collector<Tuple2<Integer, Integer>> out) {
            String[] cells = line.split("\\s+");
            //out.collect(new Tuple2<>(Integer.parseInt(cells[1]), Integer.parseInt(cells[2])));
            out.collect(new Tuple2<>(1, Integer.parseInt(cells[2])));
        }
    }
    
    public static class Node implements Serializable
    {
        Double val; // maintain the lowest aggregate at the leaf node
        Double agg;
    }

        // Get CPU time in nanoseconds. 
public static long getCpuTime( ) {
    ThreadMXBean bean = ManagementFactory.getThreadMXBean( );
    return bean.isCurrentThreadCpuTimeSupported( ) ?
        bean.getCurrentThreadCpuTime( ) : 0L;
}
 
// Get user time in nanoseconds. 
public static long getUserTime( ) {
    ThreadMXBean bean = ManagementFactory.getThreadMXBean( );
    return bean.isCurrentThreadCpuTimeSupported( ) ?
        bean.getCurrentThreadUserTime( ) : 0L;
}

// Get system time in nanoseconds. 
public static long getSystemTime( ) {
    ThreadMXBean bean = ManagementFactory.getThreadMXBean( );
    return bean.isCurrentThreadCpuTimeSupported( ) ?
        (bean.getCurrentThreadCpuTime( ) - bean.getCurrentThreadUserTime( )) : 0L;
}

}
//Two_Stacks Approach ========================End 2018321=============================
//Two_Stacks Approach ========================End 2018321=============================
//Two_Stacks Approach ========================End 2018321=============================
//Two_Stacks Approach ========================End 2018321=============================
//Two_Stacks Approach ========================End 2018321=============================
//Two_Stacks Approach ========================End 2018321=============================
*/





/*
//DABA Approach ========================Begin 2018321===========================
//DABA Approach ========================Begin 2018321===========================
//DABA Approach ========================Begin 2018321===========================
//DABA Approach ========================Begin 2018321===========================
//DABA Approach ========================Begin 2018321===========================
//DABA Approach ========================Begin 2018321===========================
public class Sum {
public static void main(String[] args) throws Exception{
// TODO code application logic here
final StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
//env.setStreamTimeCharacteristic(TimeCharacteristic.ProcessingTime);
//env.setParallelism(1);



DataStream<Tuple2<Integer,Integer>> datastream = env.readTextFile("/home/savong/デスクトップ/DEBS2012_Dataset/DEBS2012_129millions.txt")//DEB12/DEBS2012-ChallengeData.txt") //5000000.txt //50000.txt
//DataStream<Tuple2<Integer,Integer>> datastream = env.readTextFile("/home/savong/デスクトップ/DEBS2012_Dataset/DEBS2012_129millions.txt")//DEB12/DEBS2012-ChallengeData.txt") //5000000.txt //50000.txt
//DataStream<Tuple2<Integer,Integer>> datastream = env.readTextFile("/home/savong/デスクトップ/DEBS2012_Dataset/50000.txt")
.flatMap(new LineSplitter2());


long startCpuTimeNano = getCpuTime( );
long startSystemTimeNano = getSystemTime( );
long startUserTimeNano   = getUserTime( );
long tStart= System.currentTimeMillis();//=0;// = System.currentTimeMillis();
long tEnd=0;
Double elapsedSeconds=0.0;



int range = 100000;
int slide = 1;
int f2 = range%slide;
int f1 = slide - f2;
if(f2==0)
{
int num_slide = range/slide;
//Stack<Node> F = new Stack();
//Stack<Node> B = new Stack();
DoublyLinkedList vals = new DoublyLinkedList();
DoublyLinkedList aggs = new DoublyLinkedList();


datastream
.keyBy(0)
.countWindow(range,slide).trigger(PurgingTrigger.of(CountTrigger.of(slide)))//.evictor(CountEvictor.of(slide))
.fold(new Double (0.0), new FoldFunction<Tuple2<Integer, Integer>, Double>() {
int f1_value=0;
int count=0;
int round_tmp=0;
int round=0;
int window=0;
int F=1;
int L=1;
int R=1;
int A=1;
int B=1;
int E=1;
//DoublyLinkedList vals = new DoublyLinkedList(new double[num_slide]);
//DoublyLinkedList aggs = new DoublyLinkedList(new double[num_slide]);


double AggF=0; double AggL=0; double AggR=0; double AggA=0; double AggB=0; double AggE=0;
@Override
public Double fold(Double acc, Tuple2<Integer, Integer> value) throws Exception{
count++;
round_tmp++;
window++;
if(count<=f1)
{
    f1_value+=value.f1;
}
//if(round_tmp%slide==0)
if(round_tmp>=slide)
{
    if(F==B)
        AggF=0;
    else
        AggF=aggs.get(F).head;

    if(B==E)
        AggB=0;
    else
        AggB=aggs.get(E-1).head;

    if(window > range)
    {
        System.out.println("one full window");
        //Evict
        vals.remove(1);
        aggs.remove(1);
        L=L-1; R=R-1; A=A-1; B=B-1; E=E-1;
        //Fixup
        if(F==B)
        {
            B=E; A=E; R=E; L=E;
        }
        else
        {
            if(L==B)
            {
                L=F; A=E; B=E;
            }
            if(L==R)
            {
                A=A+1; R=R+1; L=L+1;
            }
            else
            {
                if(L==R)
                    AggL=0;
                else
                    AggL=aggs.get(L).head;

                if(R==A)
                    AggR=0;
                else
                    AggR=aggs.get(A-1).head;

                if(A==B)
                    AggA=0;
                else
                    AggA=aggs.get(A).head;

                aggs.get(L).head = AggL+AggR+AggA;
                //System.out.println("aggs: "+aggs.toString());
                L=L+1;
                aggs.get(A-1).head= vals.get(A-1).head+AggA;
                //System.out.println("aggs: "+aggs.toString());
                A=A-1;
            }
        }
    }

    if(F==B)
        AggF=0;
    else
        AggF=aggs.get(F).head;

    if(B==E)
        AggB=0;
    else
        AggB=aggs.get(E-1).head;
    //Insert
    vals.insertBack(f1_value);
    aggs.insertBack(f1_value+AggB);
    //System.out.println("vals: "+vals.toString());
    //System.out.println("aggs: "+aggs.toString());
    E++;
    //Fixup
    if(F==B)
    {
        B=E; A=E; R=E; L=E;
    }
    else
    {
        if(L==B)
        {
            L=F; A=E; B=E;
        }
        if(L==R)
        {
            A=A+1; R=R+1; L=L+1;
        }
        else
        {
            if(L==R)
                AggL=0;
            else
                AggL=aggs.get(L).head;

            if(R==A)
                AggR=0;
            else
                AggR=aggs.get(A-1).head;

            if(A==B)
                AggA=0;
            else
                AggA=aggs.get(A).head;

            aggs.get(L).head = AggL+AggR+AggA;
            //System.out.println("aggs: "+aggs.toString());
            L=L+1;
            aggs.get(A-1).head= vals.get(A-1).head+AggA;
            //System.out.println("aggs: "+aggs.toString());
            A=A-1;
        }
    }


    if(F==B)
        AggF=0;
    else
        AggF=aggs.get(F).head;

    if(B==E)
        AggB=0;
    else
        AggB=aggs.get(E-1).head;

    //result
    double results = AggF+AggB;


    count=0;
    f1_value=0;
    round_tmp=0;
    acc = results;
}
return acc;
}
});//.print();//.writeAsText("/Users/bousavong/Desktop/test/text/DEB12/bidirection.txt");//.print();
}
else
{
    //Stack<Node> F = new Stack();
    //Stack<Node> B = new Stack();
    int num_slide = range/slide+1;


    datastream
    .keyBy(0)
    .countWindow(range,slide).trigger(PurgingTrigger.of(CountTrigger.of(slide)))//.evictor(CountEvictor.of(slide))
    .fold(new Integer (0), new FoldFunction<Tuple2<Integer, Integer>, Integer>() {
    int f1_value=0;
    int f2_value=0;
    int count=0;
    int round_tmp=0;
    int round=0;
    int window = 0;
    @Override
    public Integer fold(Integer acc, Tuple2<Integer, Integer> value) throws Exception{
    count++;
    round_tmp++;
    window++;
    if(count<=f1)
    {
        f1_value+=value.f1;
    }
    else if (count <= f2+f1)
    {
        f2_value+=value.f1;
    }

    //double forward_aggregate = tree_aggregation[round]+f1_value;
    if(round_tmp>=slide)
    {
        round++;
        if(round==num_slide)
            round=0;

        //result
        double results=0.0;


        count=0;
        f1_value=0;
        f2_value=0;
        round_tmp=0;
        acc = (int)results;
    }
    return acc;
    }
    });//.print();//.writeAsText("/Users/bousavong/Desktop/test/text/DEB12/bidirection.txt");//.print();
}
    env.execute("Word Count Example");
    tEnd = System.currentTimeMillis();
    elapsedSeconds = (tEnd - tStart) / 1000.0;
    double taskCpuTimeNano    = (getCpuTime( ) - startCpuTimeNano)/ 1000000000.0;
    double taskUserTimeNano    = (getUserTime( ) - startUserTimeNano)/ 1000000000.0;
    double taskSystemTimeNano  = (getSystemTime( ) - startSystemTimeNano)/ 1000000000.0;
    System.out.println("taskCpuTimeNano:"+taskCpuTimeNano);
    System.out.println("taskUserTimeNano:"+taskUserTimeNano);
    System.out.println("taskSystemTimeNano:"+taskSystemTimeNano);
    System.out.println("Time:"+elapsedSeconds);
    System.out.println("Finish");
}
public static class LineSplitter implements FlatMapFunction<String, Tuple11<Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer>> {
    @Override
    public void flatMap(String line, Collector<Tuple11<Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer>> out) {
        String[] cells = line.split("\\s+");
        out.collect(new Tuple11<>(1, Integer.parseInt(cells[1]), Integer.parseInt(cells[2]), Integer.parseInt(cells[3]), Integer.parseInt(cells[4]), Integer.parseInt(cells[5]), Integer.parseInt(cells[6]), Integer.parseInt(cells[7]), Integer.parseInt(cells[8]), Integer.parseInt(cells[9]), Integer.parseInt(cells[10])));
    }
}

public static class LineSplitter2 implements FlatMapFunction<String, Tuple2<Integer, Integer>> {
    @Override
    public void flatMap(String line, Collector<Tuple2<Integer, Integer>> out) {
        String[] cells = line.split("\\s+");
        //out.collect(new Tuple2<>(Integer.parseInt(cells[1]), Integer.parseInt(cells[2])));
        out.collect(new Tuple2<>(1, Integer.parseInt(cells[2])));
    }
}

// Get CPU time in nanoseconds. 
public static long getCpuTime( ) {
    ThreadMXBean bean = ManagementFactory.getThreadMXBean( );
    return bean.isCurrentThreadCpuTimeSupported( ) ?
        bean.getCurrentThreadCpuTime( ) : 0L;
}
 
// Get user time in nanoseconds. 
public static long getUserTime( ) {
    ThreadMXBean bean = ManagementFactory.getThreadMXBean( );
    return bean.isCurrentThreadCpuTimeSupported( ) ?
        bean.getCurrentThreadUserTime( ) : 0L;
}

// Get system time in nanoseconds. 
public static long getSystemTime( ) {
    ThreadMXBean bean = ManagementFactory.getThreadMXBean( );
    return bean.isCurrentThreadCpuTimeSupported( ) ?
        (bean.getCurrentThreadCpuTime( ) - bean.getCurrentThreadUserTime( )) : 0L;
}

public static class DoublyLinkedList implements Serializable{// implements List {
public DNode sentinel;

public DoublyLinkedList(double[] array) {
    sentinel = new DNode(0);
    fromArray(array);
}

public DoublyLinkedList() {
    sentinel = new DNode(0);
}

//
// Converts an array of ints into a DoublyLinkedList
// of ints.
// @param array : array of ints
//
public void fromArray(double[] array) {
    DNode pointer = sentinel;
    for (int i=0;i<array.length;i++) {
        sentinel.head += 1;
        pointer.next = new DNode(pointer, array[i], null);
        pointer = pointer.next;
    }
}


// Get element at index i, or get the last element if
// the index is beyond the length of the list.
// @param i
// @return

public DNode get(int i) {
    DNode pointer = sentinel;
    while (i > 0 && pointer.next != null) {
        pointer = pointer.next;
        i -= 1;
    }
    return pointer;
}


// Inserts a given value into the doubly-linked list:
// - inserts at the end if the index exceeds array length
// - inserts at 0th index if index if negative
// @param i: int
// @param value: int

public void insert(int i, double value) {
    DNode pointer = get(i);
    DNode insert = new DNode(pointer, value, pointer.next);
    if (pointer.next != null)
        pointer.next.prev = insert;
    pointer.next = insert;
    sentinel.head += 1;
}


// Removes, from the doubly-linked list, the element at
// the specified index, or terminate if the index given
// is invalid.
// @param i: int

public void remove(int i) {
    if (i < 0 || i >= sentinel.head) return;
        DNode pointer = get(i-1);
    if (pointer.next.next != null)
        pointer.next.next.prev = pointer;
    pointer.next = pointer.next.next;
    sentinel.head-= 1;
}


// Convert doubly-linked list into a string representation
// for testing use.
// @return String

public String toString() {
    DNode pointer = sentinel.next;
    StringBuilder str = new StringBuilder("[");
    while (pointer != null) {
        str.append(pointer.head+" ");
        pointer = pointer.next;
    }
    return str.append("]").toString();
}

// Making insertFront easier with general insert function
public void insertFront(double value) {
    insert(0, value);
}

// Making insertBack easier with insert and sentinel (size)
public void insertBack(double value) {
    insert((int)sentinel.head, value);
}

class DNode implements Serializable{
    public double head;
    public DNode prev;
    public DNode next;

    public DNode(double _head) {
        head = _head;
    }

    public DNode(DNode _prev, double _head, DNode _next) {
        prev = _prev;
        head = _head;
        next = _next;
    }
}
}
}
//DABA Approach ========================End 2018321=============================
//DABA Approach ========================End 2018321=============================
//DABA Approach ========================End 2018321=============================
//DABA Approach ========================End 2018321=============================
//DABA Approach ========================End 2018321=============================
//DABA Approach ========================End 2018321=============================
*/