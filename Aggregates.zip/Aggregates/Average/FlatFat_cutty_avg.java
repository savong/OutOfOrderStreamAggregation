/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bidirectional_incremental_computation;

/**
 *
 * @author savong
 */
import java.io.Serializable;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Stack;
import org.apache.flink.api.common.functions.FlatMapFunction;
import org.apache.flink.api.common.functions.FoldFunction;
import org.apache.flink.api.java.tuple.Tuple11;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.windowing.evictors.CountEvictor;
import org.apache.flink.streaming.api.windowing.triggers.CountTrigger;
import org.apache.flink.streaming.api.windowing.triggers.PurgingTrigger;
import org.apache.flink.util.Collector;
import java.lang.management.*;
/**
 *
 * @author bousavong
 */




public class FlatFat_cutty_avg {
    public static void FlatFat{
                // TODO code application logic here
        final StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        //env.setStreamTimeCharacteristic(TimeCharacteristic.ProcessingTime);
        //env.setParallelism(1);
        DataStream<Tuple2<Integer,Integer>> datastream = env.readTextFile("/DEBS2012_Dataset/DEBS2012_129millions.txt")//DEB12/DEBS2012-ChallengeData.txt") //5000000.txt //50000.txt
        .flatMap(new LineSplitter2());
        
                long startCpuTimeNano = getCpuTime( );
        long startSystemTimeNano = getSystemTime( );
        long startUserTimeNano   = getUserTime( );
        long tStart= System.currentTimeMillis();//=0;// = System.currentTimeMillis();
        long tEnd=0;
        Double elapsedSeconds=0.0;

        

                int range = 10;
                int slide = 1;
                int f2 = range%slide;
                int f1 = slide - f2;
                if(f2==0)
                {
                    int num_slide = range/slide;
                    Node Tree = BST(num_slide);
                datastream
                    .keyBy(0)
                    .countWindow(range,slide).trigger(PurgingTrigger.of(CountTrigger.of(slide)))//.evictor(CountEvictor.of(slide))
                    .fold(new Double (0.0), new FoldFunction<Tuple2<Integer, Integer>, Double>() {
                       int f1_value=0;
                       int f2_value=0;
                       int count=0;
                       int round_tmp=0;
                       int round=0;
                       boolean n_round = false;
                       @Override
                       public Double fold(Double acc, Tuple2<Integer, Integer> value) throws Exception{
                        count++;
                        round_tmp++;

                        //acc+=value.f1;
                        if(count<=f1)
                        {
                            f1_value+=value.f1;
                        }

                        //if(round_tmp%slide==0)
                        if(round_tmp>=slide)
                        {
                            round_tmp=0;
                            round++;
                            if(round==num_slide+1)
                            {
                                n_round = true;
                                round=1;
                            }
                            insert(Tree, round, f1_value, 1);                            
                            count=0;
                            f1_value=0;
                        Double result=(double)Tree.aggregating;
                        if(n_round)
                            acc = result/range;
                        else
                            acc = result/(round*slide);
                        }
                        return acc;
                       }
                    });//.print();
                }
                else
                {
                    int num_slide = range/slide+1;
                    Node Tree = BST(num_slide);
                    datastream
                    .keyBy(0)
                    .countWindow(range,slide).trigger(PurgingTrigger.of(CountTrigger.of(slide)))//.evictor(CountEvictor.of(slide))
                    .fold(new Double (0.0), new FoldFunction<Tuple2<Integer, Integer>, Double>() {
                       int f1_value=0;
                       int f2_value=0;
                       int count=0;
                       int round_tmp=0;
                       int round=0;
                       boolean n_round = false;
                       @Override
                       public Double fold(Double acc, Tuple2<Integer, Integer> value) throws Exception{
                        count++;
                        round_tmp++;

                        //acc+=value.f1;
                        if(count<=f1)
                        {
                            f1_value+=value.f1;
                        }
                        else if (count <= f2+f1)
                        {
                            f2_value+=value.f1;
                        }

                        //if(round_tmp%slide==0)
                        if(round_tmp>=slide)
                        {
                            round_tmp=0;
                            round++;
                            insert2(Tree, round, f1_value, 1);
                            if(round==num_slide)
                            {
                                round=0;
                                n_round = true;
                            }
                               
                            insert2(Tree, round+1, f2_value, 2);
                            count=0;
                            f1_value=0;
                            f2_value=0;
                        Double result=(double)Tree.aggregating;
                        if(n_round)
                            acc = result/range;
                        else
                            acc = result/(round*slide);
                        }
                           return acc;
                       }
                    });//.print();
                }

        env.execute("Word Count Example");
        tEnd = System.currentTimeMillis();
        elapsedSeconds = (tEnd - tStart) / 1000.0;
        double taskCpuTimeNano    = (getCpuTime( ) - startCpuTimeNano) / 1000000000.0;
        double taskUserTimeNano    = (getUserTime( ) - startUserTimeNano) / 1000000000.0;
        double taskSystemTimeNano  = (getSystemTime( ) - startSystemTimeNano) / 1000000000.0;
        System.out.println("taskCpuTimeNano:"+taskCpuTimeNano);
        System.out.println("taskUserTimeNano:"+taskUserTimeNano);
        System.out.println("taskSystemTimeNano:"+taskSystemTimeNano);
        System.out.println("Time:"+elapsedSeconds);
        System.out.println("Finish");
    }
    public static class LineSplitter implements FlatMapFunction<String, Tuple11<Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer>> {
        @Override
        public void flatMap(String line, Collector<Tuple11<Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer, Integer>> out) {
            String[] cells = line.split("\\s+");
            out.collect(new Tuple11<>(1, Integer.parseInt(cells[1]), Integer.parseInt(cells[2]), Integer.parseInt(cells[3]), Integer.parseInt(cells[4]), Integer.parseInt(cells[5]), Integer.parseInt(cells[6]), Integer.parseInt(cells[7]), Integer.parseInt(cells[8]), Integer.parseInt(cells[9]), Integer.parseInt(cells[10])));
        }
    }

    public static class LineSplitter2 implements FlatMapFunction<String, Tuple2<Integer, Integer>> {
        @Override
        public void flatMap(String line, Collector<Tuple2<Integer, Integer>> out) {
            String[] cells = line.split("\\s+");
            //out.collect(new Tuple2<>(Integer.parseInt(cells[1]), Integer.parseInt(cells[2])));
            out.collect(new Tuple2<>(1, Integer.parseInt(cells[2])));
        }
    }
    //f1!=0, f20=0
        public static void insert(Node node, double tosearch, double aggregate, int f1f2) {
            //temperarily load
            ArrayList<Node> Tree_tmp = new ArrayList<>();
            for(int k=0;k<50;k++)
            {
                Node tmp=null;
                Tree_tmp.add(k, tmp);
            }
            //temperarily load

            if (tosearch < node.value) {
            if (node.left != null) {
                insert(node.left, tosearch, aggregate, f1f2);
                node.aggregating = node.left.aggregating+node.right.aggregating;
                }
            } else if (tosearch > node.value) {
                if (node.right != null) {
                    insert(node.right, tosearch, aggregate, f1f2);
                    node.aggregating = node.left.aggregating+node.right.aggregating;
                }
            }
            else
            {
                node.aggregating = aggregate;
            }
                
        }
        //f1!=, f2==0;

             //f1!=0, f2!=0
        public static void insert2(Node node, double tosearch, double aggregate, int f1f2) {
            if (tosearch < node.value) {
            if (node.left != null) {
                insert2(node.left, tosearch, aggregate, f1f2);
                node.aggregating = node.left.aggregating+node.right.aggregating;
                }
            } else if (tosearch > node.value) {
                if (node.right != null) {
                    insert2(node.right, tosearch, aggregate, f1f2);
                    node.aggregating = node.left.aggregating+node.right.aggregating;
                }
            }
            else
            {
                if(f1f2==1) //if f1_value, sum
                    node.aggregating += aggregate;
                else //if f2_value, overwrite
                    node.aggregating = aggregate;
            }
                
        }
        //f1!=, f2!=0;
        
        public static class Node implements Serializable
        {
            Node left;
            Node right;
            double value;
            double aggregating;
            double biggest_leaf_node;
            double smallest_leaf_node;
            public Node(double value) {
                this.value = value;
            }
        }
        static Node BST(Integer num_slide)
        {
            Node Tree;
            HashMap<Integer, Node> Leaf_nodes = new HashMap<>();
            Node tree = new Node(0);
            for(int i=1;i<=num_slide;i++)
            {
                Node level_node = new Node(i);
                level_node.biggest_leaf_node = i;
                level_node.smallest_leaf_node = i;
                Leaf_nodes.put(i, level_node);
            }
            
            while(true)
            {
                HashMap<Integer, Node> Leaf_nodes_tmp = new HashMap<>();
                for(int i=1;i<=Leaf_nodes.size();i++)
                {
                    if(i%2==1)//(k==1)
                    {
                        if(i<Leaf_nodes.size())
                        {
                            Node tmp1 = new Node(0);
                            tmp1.left= Leaf_nodes.get(i);
                            tmp1.value+=Leaf_nodes.get(i).value;
                            tmp1.biggest_leaf_node = Leaf_nodes.get(i).biggest_leaf_node;
                            tmp1.smallest_leaf_node = Leaf_nodes.get(i).smallest_leaf_node;
                            Leaf_nodes_tmp.put(Leaf_nodes_tmp.size()+1, tmp1);
                        }
                        else
                        {
                            Leaf_nodes_tmp.put(Leaf_nodes_tmp.size()+1, Leaf_nodes.get(i));
                        }
                    }
                    else// if(k==2)
                    {
                        Leaf_nodes_tmp.get(Leaf_nodes_tmp.size()).right=Leaf_nodes.get(i);//tmp1;
                        //Leaf_nodes_tmp.get(Leaf_nodes_tmp.size()).value =(Leaf_nodes_tmp.get(Leaf_nodes_tmp.size()).value+Leaf_nodes.get(i).value)/2;
                        Leaf_nodes_tmp.get(Leaf_nodes_tmp.size()).value =(Leaf_nodes_tmp.get(Leaf_nodes_tmp.size()).biggest_leaf_node+Leaf_nodes.get(i).smallest_leaf_node)/2;
                        Leaf_nodes_tmp.get(Leaf_nodes_tmp.size()).biggest_leaf_node = Leaf_nodes.get(i).biggest_leaf_node;
                        Leaf_nodes_tmp.get(Leaf_nodes_tmp.size()).smallest_leaf_node = Leaf_nodes_tmp.get(Leaf_nodes_tmp.size()).smallest_leaf_node;
                    }   
                }
                Leaf_nodes = Leaf_nodes_tmp;
                if(Leaf_nodes.size()==1)
                {
                    Tree=Leaf_nodes.get(1);
                    break;
                } 
            }
            return Tree;
        }
        
               // Get CPU time in nanoseconds. 
public static long getCpuTime( ) {
    ThreadMXBean bean = ManagementFactory.getThreadMXBean( );
    return bean.isCurrentThreadCpuTimeSupported( ) ?
        bean.getCurrentThreadCpuTime( ) : 0L;
}
 
// Get user time in nanoseconds. 
public static long getUserTime( ) {
    ThreadMXBean bean = ManagementFactory.getThreadMXBean( );
    return bean.isCurrentThreadCpuTimeSupported( ) ?
        bean.getCurrentThreadUserTime( ) : 0L;
}

// Get system time in nanoseconds. 
public static long getSystemTime( ) {
    ThreadMXBean bean = ManagementFactory.getThreadMXBean( );
    return bean.isCurrentThreadCpuTimeSupported( ) ?
        (bean.getCurrentThreadCpuTime( ) - bean.getCurrentThreadUserTime( )) : 0L;
}
}
